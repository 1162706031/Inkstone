from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from redis import Redis

from ai_platform.api.errors import install_errors
from ai_platform.chat.deletion import router as deletion_router
from ai_platform.chat.router import router as chat_router
from ai_platform.db import connection
from ai_platform.identity.router import router as identity_router
from ai_platform.models.router import router as models_router
from ai_platform.settings import settings


class Health(BaseModel):
    status: Literal["ok"]


app = FastAPI(title="AI Platform", version="0.1.0")
install_errors(app)
app.include_router(identity_router)
app.include_router(models_router)
app.include_router(chat_router)
app.include_router(deletion_router)


@app.get("/api/health", operation_id="getHealth")
def health() -> Health:
    return Health(status="ok")


@app.get("/api/v1/health/live", operation_id="getLiveness")
def liveness() -> Health:
    return Health(status="ok")


@app.get("/api/v1/health/ready", operation_id="getReadiness")
def readiness() -> Health:
    url = settings().redis_url
    if not url:
        raise HTTPException(503, "Dependency unavailable")
    with connection() as conn, Redis.from_url(url, socket_connect_timeout=3, socket_timeout=3) as redis:
        conn.execute("SELECT 1")
        if not redis.ping():
            raise HTTPException(503, "Dependency unavailable")
    return Health(status="ok")
