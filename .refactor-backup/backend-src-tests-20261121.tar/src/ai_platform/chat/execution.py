import asyncio
import time
from datetime import timedelta

import psycopg
from psycopg.types.json import Jsonb
from redis.exceptions import RedisError

from ai_platform.chat.context import ChatError, Context, cache, cost
from ai_platform.db import connection
from ai_platform.models import execution as root, metering, provider
from ai_platform.security import decrypt

ACTIVE = ("queued", "running", "cancel_requested")


class LeaseLost(Exception):
    pass


def guard(conn, job):
    if not root.locked_job(conn, job, job["worker"]):
        raise LeaseLost()
    return conn.execute("SELECT status FROM app.runs WHERE id=%s", (job["run_id"],)).fetchone()["status"]


def emit_text(conn, job, text):
    # The absolute prefix and locked projection make a lost commit acknowledgement safe to retry.
    row = conn.execute(
        "SELECT content FROM app.messages WHERE id=%s FOR UPDATE", (job["output_message_id"],)
    ).fetchone()
    block = row["content"][0]
    previous = block["text"]
    if previous == text:
        return
    if not text.startswith(previous):
        raise ChatError("PROJECTION_CONFLICT")
    refs = {"message_id": str(job["output_message_id"]), "block_id": block["block_id"]}
    if not previous:
        root.event(conn, job["run_id"], "message.started", refs)
    seq = root.event(
        conn, job["run_id"], "message.delta", {**refs, "operation": "append", "text": text[len(previous) :]}
    )
    conn.execute(
        """UPDATE app.messages SET content=%s,status='streaming',projected_event_seq=%s,
        updated_at=now() WHERE id=%s""",
        (Jsonb([{**block, "text": text}]), seq, job["output_message_id"]),
    )


def terminal(conn, job, status, error=None, text=None):
    if text is not None:
        emit_text(conn, job, text)
    run = job["run_id"]
    row = conn.execute(
        """UPDATE app.messages SET status=%s,updated_at=now() WHERE id=%s RETURNING content""",
        (status, job["output_message_id"]),
    ).fetchone()
    seq = root.event(
        conn,
        run,
        "message.snapshot",
        {"message_id": str(job["output_message_id"]), "content": row["content"], "status": status},
    )
    conn.execute(
        "UPDATE app.messages SET projected_event_seq=%s WHERE id=%s", (seq, job["output_message_id"])
    )
    conn.execute("UPDATE app.messages SET status='completed' WHERE id=%s", (job["input_message_id"],))
    conn.execute(
        """UPDATE app.runs SET status=%s,error_code=%s,finished_at=now(),updated_at=now()
        WHERE id=%s""",
        (status, error, run),
    )
    conn.execute("UPDATE app.execution_jobs SET status='done',lease_until=NULL WHERE run_id=%s", (run,))
    root.event(conn, run, "run." + status, {"status": status, "error_code": error})
    conn.execute(
        """UPDATE app.model_call_attempts SET result_expires_at=now()+interval '24 hours'
        FROM app.model_calls c WHERE model_call_attempts.model_call_id=c.id AND c.run_id=%s
        AND recoverable_result IS NOT NULL""",
        (run,),
    )
    if status != "completed":
        conn.execute(
            "UPDATE app.conversations SET thread_id=gen_random_uuid() WHERE id=%s AND thread_id=%s",
            (job["conversation_id"], job["thread_id"]),
        )


def claim(conn, worker):
    job = conn.execute("""SELECT j.run_id,j.fencing_token,r.started_at,r.created_at,r.workspace_id,r.actor_user_id,
        r.status,r.conversation_id,r.thread_id,r.input_message_id,r.output_message_id,v.config,m.snapshot,
        m.model_definition_id,i.sequence AS input_sequence,i.content->0->>'text' AS input_text
        FROM app.execution_jobs j JOIN app.runs r ON r.id=j.run_id
        JOIN app.agent_versions v ON v.id=r.agent_version_id
        JOIN app.model_config_versions m ON m.id=v.model_config_version_id JOIN app.messages i ON i.id=r.input_message_id
        WHERE r.kind='chat' AND ((j.status='ready' AND j.available_at<=now()) OR
            (j.status='leased' AND j.lease_until<=now())) ORDER BY j.available_at,j.id
        LIMIT 1 FOR UPDATE OF j SKIP LOCKED""").fetchone()
    if not job:
        return None
    run = job["run_id"]
    # An abandoned dispatch holds admission until its original upstream deadline.
    pending = conn.execute(
        """SELECT a.*,c.id AS call FROM app.model_calls c JOIN app.model_call_attempts a
        ON a.model_call_id=c.id WHERE c.run_id=%s AND a.state='dispatching'""",
        (run,),
    ).fetchone()
    if pending:
        if pending["deadline_at"] > root.now():
            conn.execute(
                """UPDATE app.execution_jobs SET status='ready',lease_owner=NULL,lease_until=NULL,
                available_at=%s WHERE run_id=%s""",
                (pending["deadline_at"], run),
            )
            return None
        settle(conn, job, pending["call"], pending["id"], None, "interrupted", "RESULT_UNKNOWN", None)
        terminal(conn, job, "interrupted", "RESULT_UNKNOWN")
        return None
    if job["status"] == "cancel_requested":
        terminal(conn, job, "cancelled")
        return None
    if not job["started_at"] and job["created_at"] + timedelta(minutes=5) <= root.now():
        terminal(conn, job, "failed", "QUEUE_TIMEOUT")
        return None
    job["worker"] = worker
    job["fencing_token"] += 1
    conn.execute(
        """UPDATE app.execution_jobs SET status='leased',lease_owner=%s,fencing_token=%s,
        lease_until=clock_timestamp()+interval '30 seconds' WHERE run_id=%s""",
        (worker, job["fencing_token"], run),
    )
    started = conn.execute(
        """UPDATE app.runs SET status='running',started_at=coalesce(started_at,now()),
        fencing_token=%s WHERE id=%s RETURNING started_at""",
        (job["fencing_token"], run),
    ).fetchone()
    if not job["started_at"]:
        root.event(conn, run, "run.started", {"status": "running"})
    job["started_at"] = started["started_at"]
    job["deadline"] = job["started_at"] + timedelta(seconds=180)
    return job


def settle(conn, job, call, attempt, usage, state, error, result):
    metering.settle(conn, attempt, usage)
    conn.execute(
        """UPDATE app.model_call_attempts SET state=%s,error_code=%s,finished_at=now(),
        recoverable_result=%s,result_expires_at=now()+interval '7 days' WHERE id=%s""",
        (state, error, Jsonb(result) if result is not None else None, attempt),
    )
    conn.execute("UPDATE app.model_calls SET status=%s WHERE id=%s", (state, call))
    root.event(
        conn,
        job["run_id"],
        "usage.updated",
        {"attempt_id": str(attempt), "usage_source": "reported" if usage else "unknown"},
    )


def prior_result(conn, job, purpose):
    return conn.execute(
        """SELECT a.state,a.error_code,a.recoverable_result FROM app.model_calls c
        JOIN app.model_call_attempts a ON a.model_call_id=c.id WHERE c.run_id=%s AND c.logical_call_key=%s""",
        (job["run_id"], purpose),
    ).fetchone()


class WriteBuffer:
    def __init__(self, job, visible):
        self.job = job
        self.visible = visible
        self.text = ""
        self.pending = 0
        self.due = None
        self.first = True

    async def receive(self, fragment):
        self.text += fragment
        if not self.visible:
            return
        self.pending += len(fragment.encode())
        if self.due is None:
            self.due = time.monotonic() + 1
        if self.first or self.pending >= 8192:
            await self.flush()

    async def flush(self):
        while self.pending:
            try:
                with connection() as conn:
                    guard(conn, self.job)
                    emit_text(conn, self.job, self.text)
            except psycopg.OperationalError:
                if self.job["deadline"] <= root.now():
                    raise
                await asyncio.sleep(0.1)
            else:
                self.pending = 0
                self.due = None
                self.first = False


async def invoke(job, purpose, messages, output, metadata):
    endpoint = job["snapshot"]["base_url"]
    target = await provider.preflight(endpoint)
    with connection() as conn:
        conn.execute("SELECT id FROM app.users WHERE id=%s FOR SHARE", (job["actor_user_id"],))
        if guard(conn, job) == "cancel_requested":
            raise ChatError("CANCELLED")
        live = conn.execute(
            """SELECT m.id,m.strict_budget_eligible,m.request_config_generation,c.id AS connection_id,
            c.credential_version,k.nonce,k.ciphertext,k.key_version FROM app.model_definitions m
            JOIN app.model_connections c ON c.id=m.connection_id JOIN app.credential_secrets k ON k.id=c.credential_id
            JOIN app.users u ON u.id=%s JOIN app.workspaces w ON w.owner_user_id=u.id
            JOIN app.conversations v ON v.workspace_id=w.id JOIN app.agents a ON a.id=v.agent_id
            JOIN app.workspaces aw ON aw.id=a.workspace_id JOIN app.users creator ON creator.id=aw.owner_user_id
            WHERE m.id=%s AND v.id=%s AND w.id=%s AND v.status='active' AND a.status='active' AND w.status='active'
            AND u.status='active' AND c.status='active' AND m.status='active' AND c.base_url=%s
            AND (u.role='admin' OR (aw.status='active' AND creator.status='active'
                AND (creator.id=u.id OR a.visibility='public')))
            FOR SHARE OF m,c,u,w,a,v,aw,creator""",
            (
                job["actor_user_id"],
                job["model_definition_id"],
                job["conversation_id"],
                job["workspace_id"],
                endpoint,
            ),
        ).fetchone()
        if not live:
            raise ChatError("MODEL_UNAVAILABLE")
        if live["request_config_generation"] != job["snapshot"]["request_config_generation"]:
            live["strict_budget_eligible"] = False
        key = decrypt(
            live["nonce"] + live["ciphertext"], live["key_version"], root.aad(live["connection_id"], endpoint)
        )
        limit = 60 if purpose == "context_summary" else 120
        deadline = min(job["deadline"], root.now() + timedelta(seconds=limit))
        if deadline <= root.now():
            raise ChatError("RUN_TIMEOUT")
        ids, error = root.reserve_call(
            conn, job, live, purpose, deadline, 16 + output + sum(map(cost, messages))
        )
        if error:
            raise ChatError(error)
    buffer = WriteBuffer(job, purpose == "chat")
    request = asyncio.create_task(
        provider.request_text(
            target,
            key,
            job["snapshot"]["upstream_model"],
            messages,
            output,
            temperature=job["config"]["temperature"],
            timeout=max(0, (deadline - root.now()).total_seconds()),
            on_text=buffer.receive,
        )
    )
    cancelled = False
    heartbeat_at = time.monotonic() + 10
    try:
        while not request.done():
            delay = min(0.25, max(0, buffer.due - time.monotonic())) if buffer.due else 0.25
            await asyncio.wait([request], timeout=delay)
            if buffer.due and buffer.due <= time.monotonic():
                await buffer.flush()
            if not request.done():
                with connection() as conn:
                    cancelled = guard(conn, job) == "cancel_requested"
                    if time.monotonic() >= heartbeat_at:
                        conn.execute(
                            """UPDATE app.execution_jobs SET lease_until=clock_timestamp()+interval '30 seconds'
                            WHERE run_id=%s""",
                            (job["run_id"],),
                        )
                        heartbeat_at = time.monotonic() + 10
                if cancelled:
                    request.cancel()
                    break
        try:
            _, usage, error = await request
        except asyncio.CancelledError:
            usage, error = None, "CANCELLED"
    finally:
        if not request.done():
            request.cancel()
            await asyncio.gather(request, return_exceptions=True)
    uncertain = error in ("UPSTREAM_INTERRUPTED", "UPSTREAM_TIMEOUT", "UPSTREAM_PROTOCOL")
    with connection() as conn:
        cancelled = guard(conn, job) == "cancel_requested" or cancelled
        result = {**metadata, "text": buffer.text}
        state = "interrupted" if uncertain else ("failed" if error else "completed")
        settle(conn, job, *ids, usage, state, error, result)
        if purpose == "chat":
            job["tail"] = buffer.text
    if cancelled:
        raise ChatError("CANCELLED")
    if uncertain:
        raise ChatError("RESULT_UNKNOWN")
    if error:
        raise ChatError(error)
    return result


def restored(prior):
    if prior["state"] == "completed" and prior["recoverable_result"] is not None:
        return prior["recoverable_result"]
    if prior["state"] == "failed":
        raise ChatError(prior["error_code"])
    raise ChatError("RESULT_UNKNOWN")


def reply(job):
    with connection() as conn:
        guard(conn, job)
        prior = prior_result(conn, job, "chat")
        if prior:
            return restored(prior)
        ctx = Context.load(conn, job)
        summary_call = prior_result(conn, job, "context_summary")
    own_summary = ctx.summary and ctx.summary["run_id"] == job["run_id"]
    if not own_summary:
        request = ctx.summary_request(job["deadline"] - root.now())
        summary = None
        if summary_call and summary_call["state"] != "failed":
            summary = restored(summary_call)
        elif request and not summary_call:
            batch, output, through = request
            try:
                summary = asyncio.run(
                    invoke(job, "context_summary", batch, output, {"covered_through_seq": through})
                )
            except ChatError as exc:
                if exc.code not in ("UPSTREAM_REJECTED", "MONTHLY_QUOTA_EXCEEDED", "MODEL_ADMISSION_LIMIT"):
                    raise
        if summary:
            with connection() as conn:
                if guard(conn, job) == "cancel_requested":
                    raise ChatError("CANCELLED")
                conn.execute(
                    """INSERT INTO app.conversation_context_summaries(workspace_id,conversation_id,
                    run_id,covered_through_seq,previous_summary_id,summary_text) VALUES (%s,%s,%s,%s,%s,%s)
                    ON CONFLICT(run_id) DO NOTHING""",
                    (
                        job["workspace_id"],
                        job["conversation_id"],
                        job["run_id"],
                        summary["covered_through_seq"],
                        ctx.summary["id"] if ctx.summary else None,
                        summary["text"],
                    ),
                )
                ctx = Context.load(conn, job)
            own_summary = True
    messages, mode, plan = ctx.reply(own_summary)
    with connection() as conn:
        guard(conn, job)
        conn.execute("UPDATE app.runs SET context_compression=%s WHERE id=%s", (mode, job["run_id"]))
    return asyncio.run(invoke(job, "chat", messages, ctx.output, plan))


def run_once(worker):
    from ai_platform.chat.graph import execute_graph

    with connection() as conn:
        job = claim(conn, worker)
    if not job:
        return False
    try:
        text = execute_graph(job)
        status, error = "completed", None
    except LeaseLost:
        return True
    except (ChatError, provider.ProviderFailure, RedisError, OSError, RuntimeError) as exc:
        error = getattr(exc, "code", "DEPENDENCY_UNAVAILABLE")
        status = {"RESULT_UNKNOWN": "interrupted", "CANCELLED": "cancelled"}.get(error, "failed")
        text = job.get("tail")
    with connection() as conn:
        try:
            if guard(conn, job) == "cancel_requested":
                status, error = "cancelled", None
        except LeaseLost:
            return True
        terminal(conn, job, status, error, text)
    if status == "completed":
        cache.committed(job, text)
    return True
