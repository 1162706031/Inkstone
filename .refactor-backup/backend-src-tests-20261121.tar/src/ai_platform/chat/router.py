import asyncio
import hashlib
import json
import time

from typing import Annotated
from uuid import UUID, uuid4

from fastapi import APIRouter, Header, HTTPException, Query, Request, Response
from fastapi.routing import APIRoute
from psycopg.types.json import Jsonb
from starlette.responses import StreamingResponse

from ai_platform.chat import schemas as s
from ai_platform.identity.router import authenticated
from ai_platform.models import execution
from ai_platform.models.router import Cursor, Limit, MODELS, RUNS, get_row, page, workspace
from ai_platform.models.schemas import Page, RunView
from ai_platform.security import digest


class ChatRoute(APIRoute):
    def get_route_handler(self):
        handler = super().get_route_handler()
        if not self.body_field:
            return handler

        async def bounded(request):
            body = bytearray()
            async for chunk in request.stream():
                if len(body) + len(chunk) > 65536:
                    raise HTTPException(413, "JSON body exceeds 64 KiB")
                body.extend(chunk)

            async def receive():
                return {"type": "http.request", "body": bytes(body), "more_body": False}

            return await handler(Request(request.scope, receive=receive))

        return bounded


router = APIRouter(prefix="/api/v1", route_class=ChatRoute)
FIELDS = tuple(s.AgentConfig.model_fields)
AGENT_CATALOG = """
    SELECT a.*, creator.id AS creator_id, creator.display_name AS creator_name,
        creator.id=viewer.id AS is_creator, (viewer.admin OR creator.id=viewer.id) AS can_manage,
        a.status='active' AS can_edit, released.number AS published_version,
        v.revision AS published_revision, v.config->>'name' AS published_name,
        v.config->>'description' AS published_description
    FROM app.agents a JOIN app.workspaces aw ON aw.id=a.workspace_id
    JOIN app.users creator ON creator.id=aw.owner_user_id
    CROSS JOIN (SELECT %s::uuid AS id, %s::boolean AS admin) viewer
    LEFT JOIN LATERAL (SELECT number,version_id FROM app.agent_releases
        WHERE agent_id=a.id ORDER BY number DESC LIMIT 1) released ON true
    LEFT JOIN app.agent_versions v ON v.id=released.version_id
    WHERE (viewer.admin OR (aw.status='active' AND creator.status='active' AND
        (creator.id=viewer.id OR (a.status='active' AND a.visibility='public'))))
"""
ACTIVE = "('queued','running','cancel_requested')"
CONVERSATIONS = f"""
    SELECT c.*, v.config->>'name' AS agent_name, r.number AS release_version,
        (SELECT id FROM app.runs WHERE conversation_id=c.id AND status IN {ACTIVE}) AS active_run_id
    FROM app.conversations c
    JOIN app.agent_versions v ON v.id=c.agent_version_id
    LEFT JOIN app.agent_releases r ON r.version_id=v.id
"""


def viewer(user):
    return user["id"], user["role"] == "admin"


def agent_row(conn, user, agent, *, write=False, share=False):
    params = (*viewer(user), agent)
    if write or share:
        # Read releases in a fresh statement after concurrent editors/publishers release the lock.
        lock = " FOR UPDATE OF a" if write else " FOR SHARE OF a"
        get_row(conn, AGENT_CATALOG + " AND a.id=%s" + lock, params)
    return get_row(conn, AGENT_CATALOG + " AND a.id=%s", params)


def conversation_row(conn, owner, conversation, lock=False):
    return get_row(
        conn,
        CONVERSATIONS
        + " WHERE c.workspace_id=%s AND c.id=%s AND c.status='active'"
        + (" FOR UPDATE OF c" if lock else ""),
        (owner, conversation),
    )


def visible_run(conn, owner, run):
    return get_row(
        conn,
        RUNS
        + """ WHERE id=%s AND workspace_id=%s AND payload_purged_at IS NULL
        AND (kind='connection_test' OR EXISTS (SELECT 1 FROM app.conversations c
            WHERE c.id=runs.conversation_id AND c.status='active'))""",
        (run, owner),
    )


def config_model(conn, config):
    get_row(
        conn,
        """SELECT m.id FROM app.model_definitions m JOIN app.model_connections c ON c.id=m.connection_id
        WHERE m.id=%s FOR SHARE OF c,m""",
        (config.model_definition_id,),
        "Model unavailable",
    )
    model = get_row(
        conn,
        MODELS
        + """ WHERE m.id=%s AND m.status='active' AND c.status='active'
        AND t.status='passed'""",
        (config.model_definition_id,),
        "Model unavailable",
    )
    if config.temperature is not None and not model["supports_temperature"]:
        raise HTTPException(422, "Model does not support temperature")
    return model


def saved_config(row):
    return s.AgentConfig(**{k: row[k] for k in FIELDS})


@router.get("/agents")
def agents(request: Request, cursor: Cursor = None, limit: Limit = 20) -> Page[s.AgentView]:
    with authenticated(request) as (conn, _, user):
        return page(
            conn,
            AGENT_CATALOG + " AND a.status='active'",
            "a",
            viewer(user),
            cursor,
            limit,
            s.AgentView,
        )


@router.post("/agents", status_code=201)
def create_agent(data: s.AgentCreate, request: Request) -> s.AgentView:
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        config_model(conn, data)
        created = conn.execute(
            f"""INSERT INTO app.agents(workspace_id,visibility,{",".join(FIELDS)})
            VALUES (%s,%s,{",".join(["%s"] * len(FIELDS))}) RETURNING id""",
            (owner, data.visibility, *(getattr(data, key) for key in FIELDS)),
        ).fetchone()
        return agent_row(conn, user, created["id"])


@router.get("/agents/{agent_id}")
def agent(agent_id: UUID, request: Request) -> s.AgentView:
    with authenticated(request) as (conn, _, user):
        return agent_row(conn, user, agent_id)


@router.patch("/agents/{agent_id}")
def edit_agent(agent_id: UUID, data: s.AgentPatch, request: Request) -> s.AgentView:
    with authenticated(request) as (conn, _, user):
        row = agent_row(conn, user, agent_id, write=True)
        if row["status"] != "active" or row["revision"] != data.revision:
            raise HTTPException(409, "Agent revision conflict")
        changes = data.model_dump(exclude_unset=True, exclude={"revision"})
        if not changes or any(v is None and k != "temperature" for k, v in changes.items()):
            raise HTTPException(422, "Invalid change")
        if changes.get("visibility", row["visibility"]) != row["visibility"] and not row["can_manage"]:
            raise HTTPException(403, "仅创建者和管理员可以更改可见性")
        changes = {k: v for k, v in changes.items() if row[k] != v}
        if not changes:
            return row
        config_model(conn, saved_config({**row, **changes}))
        conn.execute(
            f"""UPDATE app.agents SET {",".join(k + "=%s" for k in changes)},
            revision=revision+1,updated_at=now() WHERE id=%s""",
            (*changes.values(), agent_id),
        )
        return agent_row(conn, user, agent_id)


@router.post("/agents/{agent_id}/validate")
def validate_agent(agent_id: UUID, request: Request):
    with authenticated(request) as (conn, _, user):
        row = agent_row(conn, user, agent_id)
        try:
            config_model(conn, saved_config(row))
        except HTTPException as exc:
            return {
                "valid": False,
                "errors": [{"field": "model_definition_id", "code": "MODEL_INVALID", "message": exc.detail}],
            }
        return {"valid": True, "errors": []}


@router.delete("/agents/{agent_id}", status_code=204)
def archive_agent(agent_id: UUID, request: Request):
    with authenticated(request) as (conn, _, user):
        row = agent_row(conn, user, agent_id, write=True)
        if not row["can_manage"]:
            raise HTTPException(403, "仅创建者和管理员可以归档")
        conn.execute("UPDATE app.agents SET status='archived',updated_at=now() WHERE id=%s", (agent_id,))


@router.get("/agents/{agent_id}/versions")
def versions(agent_id: UUID, request: Request, cursor: Cursor = None, limit: Limit = 20) -> Page[s.Version]:
    with authenticated(request) as (conn, _, user):
        row = agent_row(conn, user, agent_id, share=True)
        return page(
            conn,
            """SELECT v.*,r.number AS published_version FROM app.agent_versions v
            LEFT JOIN app.agent_releases r ON r.version_id=v.id WHERE v.workspace_id=%s AND v.agent_id=%s""",
            "v",
            (row["workspace_id"], agent_id),
            cursor,
            limit,
            s.Version,
        )


@router.post("/agents/{agent_id}/publish")
def publish(agent_id: UUID, data: s.Publish, request: Request) -> s.AgentView:
    with authenticated(request) as (conn, _, user):
        row = agent_row(conn, user, agent_id, write=True)
        if row["status"] != "active" or row["revision"] != data.revision:
            raise HTTPException(409, "Agent revision conflict")
        if row["published_revision"] == row["revision"]:
            return row
        config = saved_config(row)
        model = config_model(conn, config)
        link = get_row(
            conn, "SELECT revision,base_url FROM app.model_connections WHERE id=%s", (model["connection_id"],)
        )
        snapshot = {
            k: model[k]
            for k in (
                "upstream_model",
                "context_limit_tokens",
                "max_output_tokens",
                "supports_temperature",
                "request_config_generation",
            )
        }
        snapshot["base_url"] = link["base_url"]
        key = (model["connection_id"], model["id"], link["revision"], model["revision"])
        conn.execute(
            """INSERT INTO app.model_config_versions
            (connection_id,model_definition_id,connection_revision,model_revision,snapshot)
            VALUES (%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
            (*key, Jsonb(snapshot)),
        )
        version = get_row(
            conn,
            """SELECT id FROM app.model_config_versions WHERE
            (connection_id,model_definition_id,connection_revision,model_revision)=(%s,%s,%s,%s)""",
            key,
        )["id"]
        conn.execute(
            """INSERT INTO app.agent_versions(workspace_id,agent_id,revision,model_config_version_id,
            config,config_hash) VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
            (
                row["workspace_id"],
                agent_id,
                row["revision"],
                version,
                Jsonb(config.model_dump(mode="json")),
                hashlib.sha256(config.model_dump_json().encode()).hexdigest(),
            ),
        )
        bound = get_row(
            conn,
            """SELECT id FROM app.agent_versions WHERE
            (agent_id,revision,model_config_version_id)=(%s,%s,%s)""",
            (agent_id, row["revision"], version),
        )["id"]
        conn.execute("INSERT INTO app.agent_releases(agent_id,number,version_id) VALUES (%s,%s,%s)",
                     (agent_id, (row["published_version"] or 0) + 1, bound))
        conn.execute("UPDATE app.agents SET updated_at=now() WHERE id=%s", (agent_id,))
        return agent_row(conn, user, agent_id)


@router.post("/agents/{agent_id}/conversations", status_code=201)
def create_conversation(agent_id: UUID, data: s.NewConversation, request: Request) -> s.Conversation:
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        row = agent_row(conn, user, agent_id, share=True)
        if row["status"] != "active" or not row["published_version"]:
            raise HTTPException(409, "此智能体尚未发布或已归档")
        if data.agent_revision != row["published_revision"]:
            raise HTTPException(409, "发布版本已更新，请刷新后重试")
        released = get_row(conn, """SELECT v.id,v.config FROM app.agent_versions v
            JOIN app.agent_releases r ON r.version_id=v.id WHERE r.agent_id=%s AND r.number=%s""",
            (agent_id, row["published_version"]))
        config_model(conn, s.AgentConfig(**released["config"]))
        bound = released["id"]
        conversation = conn.execute(
            """INSERT INTO app.conversations(workspace_id,owner_user_id,agent_id,
            agent_version_id,title,status,thread_id) VALUES (%s,%s,%s,%s,%s,'active',%s) RETURNING id""",
            (owner, user["id"], agent_id, bound, data.title or "", uuid4()),
        ).fetchone()["id"]
        return conversation_row(conn, owner, conversation)


@router.get("/conversations")
def conversations(
    request: Request, agent_id: UUID | None = None, cursor: Cursor = None, limit: Limit = 20
) -> Page[s.Conversation]:
    with authenticated(request) as (conn, _, user):
        return page(
            conn,
            CONVERSATIONS
            + """ WHERE c.workspace_id=%s AND c.status='active'
            AND (%s::uuid IS NULL OR c.agent_id=%s)""",
            "c",
            (workspace(conn, user["id"]), agent_id, agent_id),
            cursor,
            limit,
            s.Conversation,
        )


@router.get("/conversations/{conversation_id}")
def conversation(conversation_id: UUID, request: Request) -> s.Conversation:
    with authenticated(request) as (conn, _, user):
        return conversation_row(conn, workspace(conn, user["id"]), conversation_id)


@router.patch("/conversations/{conversation_id}")
def rename(conversation_id: UUID, data: s.Rename, request: Request) -> s.Conversation:
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        conversation_row(conn, owner, conversation_id, True)
        conn.execute(
            "UPDATE app.conversations SET title=%s,updated_at=now() WHERE id=%s",
            (data.title, conversation_id),
        )
        return conversation_row(conn, owner, conversation_id)


@router.get("/conversations/{conversation_id}/messages")
def messages(
    conversation_id: UUID, request: Request, cursor: Annotated[int, Query(ge=0)] = 0, limit: Limit = 20
) -> s.HistoryPage:
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        # One statement snapshot includes the projection and the matching per-run watermarks.
        rows = conn.execute(
            """SELECT m.*,r.last_event_seq,r.context_compression FROM app.conversations c
            LEFT JOIN app.messages m ON m.conversation_id=c.id AND m.sequence>%s
            LEFT JOIN app.runs r ON r.id=m.run_id WHERE c.id=%s AND c.workspace_id=%s AND c.status='active'
            ORDER BY m.sequence LIMIT %s""",
            (cursor, conversation_id, owner, limit + 1),
        ).fetchall()
        if not rows:
            raise HTTPException(404, "Conversation unavailable")
        items = [r for r in rows[:limit] if r["id"]]
        return s.HistoryPage(
            items=items,
            run_cursors={r["run_id"]: r["last_event_seq"] for r in items},
            compression={r["run_id"]: r["context_compression"] or "none" for r in items},
            next_cursor=str(items[-1]["sequence"]) if len(rows) > limit else None,
        )


@router.post("/agents/{agent_id}/runs", status_code=202)
def accept_chat(
    agent_id: UUID,
    data: s.NewRun,
    request: Request,
    idempotency_key: Annotated[str, Header(min_length=1, max_length=128)],
) -> RunView:
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        agent = agent_row(conn, user, agent_id, share=True)
        conv = conversation_row(conn, owner, data.conversation_id, True)
        if conv["agent_id"] != agent_id:
            raise HTTPException(404, "Conversation unavailable")
        key = (owner, user["id"], agent_id, digest(idempotency_key))
        fingerprint = digest(data.model_dump_json())
        prior = conn.execute(
            """SELECT * FROM app.idempotency_records WHERE operation='chat'
            AND (workspace_id,actor_user_id,resource_id,key_hash)=(%s,%s,%s,%s)""",
            key,
        ).fetchone()
        if prior and prior["expires_at"] > execution.now():
            if prior["request_hash"] != fingerprint:
                raise HTTPException(409, "IDEMPOTENCY_CONFLICT")
            return visible_run(conn, owner, prior["run_id"])
        if prior:
            conn.execute("DELETE FROM app.idempotency_records WHERE id=%s", (prior["id"],))
        if agent["status"] != "active":
            raise HTTPException(409, "Agent archived")
        if not agent["published_version"]:
            raise HTTPException(409, "请先发布智能体")
        if conv["active_run_id"]:
            raise HTTPException(409, "CONVERSATION_BUSY")
        run, input_id, output_id = uuid4(), uuid4(), uuid4()
        conn.execute(
            """INSERT INTO app.runs(id,workspace_id,actor_user_id,conversation_id,agent_version_id,kind,
            status,input_message_id,output_message_id,thread_id,context_compression)
            VALUES (%s,%s,%s,%s,%s,'chat','queued',%s,%s,%s,'none')""",
            (
                run,
                owner,
                user["id"],
                conv["id"],
                conv["agent_version_id"],
                input_id,
                output_id,
                conv["thread_id"],
            ),
        )
        text = data.input.content[0].text
        for offset, (mid, role, value) in enumerate(((input_id, "user", text), (output_id, "assistant", ""))):
            content = [{"type": "text", "block_id": str(uuid4()), "text": value}]
            conn.execute(
                """INSERT INTO app.messages(id,workspace_id,conversation_id,run_id,sequence,role,
                content,status) VALUES (%s,%s,%s,%s,%s,%s,%s,'accepted')""",
                (mid, owner, conv["id"], run, conv["next_message_seq"] + offset, role, Jsonb(content)),
            )
        conn.execute(
            """UPDATE app.conversations SET next_message_seq=next_message_seq+2,
            title=CASE WHEN title='' THEN %s ELSE title END,updated_at=now() WHERE id=%s""",
            (text[:30], conv["id"]),
        )
        conn.execute("INSERT INTO app.execution_jobs(run_id) VALUES (%s)", (run,))
        conn.execute(
            """INSERT INTO app.idempotency_records(workspace_id,actor_user_id,resource_id,key_hash,
            operation,request_hash,run_id,expires_at) VALUES (%s,%s,%s,%s,'chat',%s,%s,now()+interval '24 hours')""",
            (*key, fingerprint, run),
        )
        execution.event(conn, run, "run.queued", {"status": "queued"})
        return visible_run(conn, owner, run)


@router.get("/runs/{run_id}", operation_id="getRun")
def get_run(run_id: UUID, request: Request) -> s.RunDetail:
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        row = visible_run(conn, owner, run_id)
        # Read the message and advertised watermark together even if a batch committed since the check.
        if row["output_message_id"]:
            snapshot = get_row(
                conn,
                """SELECT row_to_json(m) AS output_message,r.status,r.last_event_seq
                AS last_event_sequence,r.finished_at,r.error_code AS error,r.context_compression
                FROM app.messages m JOIN app.runs r ON r.id=m.run_id JOIN app.conversations c ON c.id=m.conversation_id
                WHERE m.id=%s AND c.workspace_id=%s AND c.status='active'""",
                (row["output_message_id"], owner),
            )
            row.update(snapshot)
        else:
            row["output_message"] = None
        return row


@router.post("/runs/{run_id}/cancel", status_code=202)
def cancel(run_id: UUID, request: Request, response: Response) -> RunView:
    from ai_platform.chat.execution import ACTIVE as active_states, terminal

    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        visible_run(conn, owner, run_id)
        conn.execute("SELECT run_id FROM app.execution_jobs WHERE run_id=%s FOR UPDATE", (run_id,))
        row = visible_run(conn, owner, run_id)
        if row["status"] not in active_states:
            response.status_code = 200
        elif row["status"] == "queued":
            if row["kind"] == "chat":
                job = get_row(conn, "SELECT *,id AS run_id FROM app.runs WHERE id=%s", (run_id,))
                terminal(conn, job, "cancelled")
            else:
                execution.finish(conn, run_id, None, cancelled=True)
        elif row["status"] == "running":
            conn.execute("UPDATE app.runs SET status='cancel_requested' WHERE id=%s", (run_id,))
            execution.event(conn, run_id, "run.cancel_requested", {"status": "cancel_requested"})
        return visible_run(conn, owner, run_id)


def read_events(request, run_id, sequence):
    with authenticated(request) as (conn, _, user):
        run = visible_run(conn, workspace(conn, user["id"]), run_id)
        if sequence > run["last_event_sequence"]:
            raise HTTPException(422, "Invalid event sequence")
        rows = conn.execute(
            """SELECT sequence,type,payload FROM app.run_events WHERE root_run_id=%s
            AND sequence>%s AND created_at>now()-interval '7 days' ORDER BY sequence LIMIT 100""",
            (run_id, sequence),
        ).fetchall()
        if sequence < run["last_event_sequence"] and (not rows or rows[0]["sequence"] != sequence + 1):
            raise HTTPException(410, "EVENT_REPLAY_EXPIRED")
        return (
            rows,
            run["status"] not in ("queued", "running", "cancel_requested"),
            run["last_event_sequence"],
        )


@router.get("/runs/{run_id}/events", response_class=StreamingResponse)
async def events(run_id: UUID, request: Request, after: str | None = None):
    cursor = request.headers.get("Last-Event-ID") or after
    sequence = 0
    if cursor is not None:
        try:
            root_id, raw = cursor.split(":")
            sequence = int(raw)
            if UUID(root_id) != run_id or sequence < 0:
                raise ValueError
        except ValueError as exc:
            raise HTTPException(422, "Invalid run cursor") from exc
    initial = await asyncio.to_thread(read_events, request, run_id, sequence)

    async def stream():
        current = sequence
        batch = initial
        heartbeat = time.monotonic() + 15
        while True:
            rows, done, last = batch
            for row in rows:
                current = row["sequence"]
                payload = dict(row["payload"])
                envelope = {
                    "schema_version": 1,
                    "root_run_id": str(run_id),
                    "run_id": str(run_id),
                    "sequence": current,
                    "type": row["type"],
                    "payload": payload,
                }
                for field in ("block_id", "message_id"):
                    if field in payload:
                        envelope[field] = payload.pop(field)
                yield f"id: {run_id}:{current}\nevent: {row['type']}\ndata: {json.dumps(envelope)}\n\n"
            if done and current >= last:
                return
            if time.monotonic() >= heartbeat:
                yield ": heartbeat\n\n"
                heartbeat = time.monotonic() + 15
            if len(rows) < 100:
                await asyncio.sleep(0.25)
            try:
                batch = await asyncio.to_thread(read_events, request, run_id, current)
            except HTTPException:
                return

    return StreamingResponse(stream(), media_type="text/event-stream", headers={"X-Accel-Buffering": "no"})
