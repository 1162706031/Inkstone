import sqlite3
from contextlib import closing

from fastapi import APIRouter, HTTPException, Request
from uuid import UUID

from ai_platform.chat.context import cache
from ai_platform.chat.router import ACTIVE
from ai_platform.db import connection
from ai_platform.identity.router import authenticated
from ai_platform.models.router import workspace
from ai_platform.settings import settings

router = APIRouter(prefix="/api/v1")
FIELDS = ("event_id", "workspace_id", "conversation_id", "deleted_at")


def archive_path():
    path = settings().deletion_archive_path
    if path is None or not path.is_absolute():
        raise OSError("Independent archive path required")
    return path


def create_archive(store):
    store.execute("""CREATE TABLE IF NOT EXISTS deletions (
        event_id TEXT PRIMARY KEY,workspace_id TEXT NOT NULL,conversation_id TEXT NOT NULL,deleted_at TEXT NOT NULL,
        UNIQUE(workspace_id,conversation_id))""")


def init_archive():
    with closing(sqlite3.connect(archive_path(), timeout=2)) as store, store:
        store.execute("PRAGMA synchronous=FULL")
        create_archive(store)


def archive(marker):
    record = tuple(str(marker[key]) for key in FIELDS)
    # mode=rw never creates a file: a missing or swapped archive must fail instead of
    # confirming deletions into a new, empty store.
    uri = archive_path().as_uri() + "?mode=rw"
    with closing(sqlite3.connect(uri, uri=True, timeout=2)) as store, store:
        store.execute("PRAGMA synchronous=FULL")
        store.execute("INSERT INTO deletions VALUES (?,?,?,?) ON CONFLICT(event_id) DO NOTHING", record)
        if store.execute("SELECT * FROM deletions WHERE event_id=?", (record[0],)).fetchone() != record:
            raise OSError("Archive record mismatch")


def confirm(marker):
    if marker["archived_at"]:
        return True
    try:
        archive(marker)
    except (sqlite3.Error, OSError):
        return False
    with connection() as conn:
        conn.execute(
            """UPDATE app.conversation_deletion_markers SET archived_at=coalesce(archived_at,now())
            WHERE event_id=%s""",
            (marker["event_id"],),
        )
    return True


@router.delete("/conversations/{conversation_id}", status_code=202)
def delete_conversation(conversation_id: UUID, request: Request):
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        row = conn.execute(
            "SELECT id FROM app.conversations WHERE workspace_id=%s AND id=%s FOR UPDATE",
            (owner, conversation_id),
        ).fetchone()
        marker = conn.execute(
            """SELECT * FROM app.conversation_deletion_markers
            WHERE workspace_id=%s AND conversation_id=%s""",
            (owner, conversation_id),
        ).fetchone()
        if not marker:
            if not row:
                raise HTTPException(404, "Conversation unavailable")
            if conn.execute(
                f"SELECT 1 FROM app.runs WHERE conversation_id=%s AND status IN {ACTIVE}", (conversation_id,)
            ).fetchone():
                raise HTTPException(409, "CONVERSATION_BUSY")
            conn.execute(
                """UPDATE app.conversations SET status='deleting',deletion_requested_at=now()
                WHERE id=%s""",
                (conversation_id,),
            )
            marker = conn.execute(
                """INSERT INTO app.conversation_deletion_markers(workspace_id,conversation_id)
                VALUES (%s,%s) RETURNING *""",
                (owner, conversation_id),
            ).fetchone()
    cache.discard((owner, conversation_id))
    if not confirm(marker):
        raise HTTPException(503, "DELETION_ARCHIVE_PENDING")
    return {"status": "deleting"}


def purge(conn, marker):
    cid = marker["conversation_id"]
    if not conn.execute(
        """SELECT id FROM app.conversations WHERE id=%s AND status='deleting'
        FOR UPDATE SKIP LOCKED""",
        (cid,),
    ).fetchone():
        return
    conn.execute(
        """DELETE FROM graph.write_receipts WHERE thread_id IN (
        SELECT thread_id FROM app.runs WHERE conversation_id=%s)""",
        (cid,),
    )
    for table in ("checkpoint_writes", "checkpoint_blobs", "checkpoints"):
        conn.execute(
            f"""DELETE FROM graph.{table} WHERE thread_id IN (
            SELECT thread_id::text FROM app.runs WHERE conversation_id=%s)""",
            (cid,),
        )
    conn.execute(
        """UPDATE app.model_call_attempts SET recoverable_result=NULL,result_message_id=NULL,
        result_expires_at=NULL FROM app.model_calls c JOIN app.runs r ON r.id=c.run_id
        WHERE model_call_attempts.model_call_id=c.id AND r.conversation_id=%s""",
        (cid,),
    )
    conn.execute(
        "DELETE FROM app.run_events WHERE run_id IN (SELECT id FROM app.runs WHERE conversation_id=%s)",
        (cid,),
    )
    conn.execute("DELETE FROM app.conversation_context_summaries WHERE conversation_id=%s", (cid,))
    conn.execute("DELETE FROM app.messages WHERE conversation_id=%s", (cid,))
    conn.execute(
        """UPDATE app.runs SET payload_purged_at=now(),conversation_id=NULL,thread_id=NULL,
        checkpoint_id=NULL,input_message_id=NULL,output_message_id=NULL WHERE conversation_id=%s""",
        (cid,),
    )
    conn.execute("DELETE FROM app.conversations WHERE id=%s", (cid,))


def replay_archive():
    """Re-apply every archived deletion to a restored database before the workbench opens.

    Fails with OSError when the independent archive is missing, so a restored instance stays isolated.
    Returns (archived records, markers applied in this database, conversations purged).
    """
    path = archive_path()
    if not path.is_file():
        raise OSError("Independent archive unavailable")
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=2)) as store:
        records = store.execute(f"SELECT {','.join(FIELDS)} FROM deletions").fetchall()
    applied = 0
    with connection() as conn:
        for event_id, workspace_id, conversation_id, deleted_at in records:
            if not conn.execute("SELECT 1 FROM app.workspaces WHERE id=%s", (workspace_id,)).fetchone():
                continue
            conn.execute(
                """INSERT INTO app.conversation_deletion_markers(event_id,workspace_id,conversation_id,
                deleted_at,archived_at) VALUES (%s,%s,%s,%s,now()) ON CONFLICT DO NOTHING""",
                (event_id, workspace_id, conversation_id, deleted_at),
            )
            conn.execute(
                """UPDATE app.conversation_deletion_markers SET archived_at=coalesce(archived_at,now())
                WHERE workspace_id=%s AND conversation_id=%s""",
                (workspace_id, conversation_id),
            )
            # Runs restored mid-flight from the backup must not continue on a deleted conversation.
            runs = conn.execute(
                f"""UPDATE app.runs SET status='cancelled',error_code='CONVERSATION_DELETED',
                finished_at=now(),updated_at=now() WHERE conversation_id=%s AND status IN {ACTIVE}
                RETURNING id""",
                (conversation_id,),
            ).fetchall()
            for run in runs:
                conn.execute(
                    "UPDATE app.execution_jobs SET status='done',lease_until=NULL WHERE run_id=%s", (run["id"],)
                )
            hidden = conn.execute(
                """UPDATE app.conversations SET status='deleting',
                deletion_requested_at=coalesce(deletion_requested_at,%s) WHERE workspace_id=%s AND id=%s
                RETURNING id""",
                (deleted_at, workspace_id, conversation_id),
            ).fetchone()
            applied += bool(hidden)
    with connection() as conn:
        before = conn.execute("SELECT count(*) AS n FROM app.conversations WHERE status='deleting'").fetchone()["n"]
    retry_archives()
    with connection() as conn:
        after = conn.execute("SELECT count(*) AS n FROM app.conversations WHERE status='deleting'").fetchone()["n"]
    return len(records), applied, before - after


def retry_archives():
    with connection() as conn:
        markers = conn.execute("""SELECT m.* FROM app.conversation_deletion_markers m
            JOIN app.conversations c ON c.id=m.conversation_id WHERE c.status='deleting'
            ORDER BY m.archived_at NULLS LAST,m.deleted_at""").fetchall()
    for marker in markers:
        if confirm(marker):
            with connection() as conn:
                purge(conn, marker)
