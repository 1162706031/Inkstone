import asyncio
from datetime import timedelta
from uuid import uuid4

from psycopg import Rollback
from psycopg.types.json import Jsonb
from redis.exceptions import RedisError

from ai_platform.db import connection
from ai_platform.identity.service import now
from ai_platform.models import metering, provider
from ai_platform.security import decrypt

TEST_PROMPT = [{"role": "user", "content": "Reply with OK."}]


def event(conn, run, kind, payload):
    row = conn.execute("""
        UPDATE app.runs SET last_event_seq=last_event_seq+1,updated_at=now()
        WHERE id=%s RETURNING last_event_seq
    """, (run,)).fetchone()
    conn.execute("""
        INSERT INTO app.run_events(root_run_id,run_id,sequence,type,payload) VALUES (%s,%s,%s,%s,%s)
    """, (run, run, row["last_event_seq"], kind, Jsonb(payload)))
    return row["last_event_seq"]


def finish(conn, run, error, *, dispatched=False, interrupted=False, cancelled=False):
    status = "cancelled" if cancelled else ("interrupted" if interrupted else ("failed" if error else "completed"))
    conn.execute("""
        UPDATE app.runs SET status=%s,error_code=%s,finished_at=now(),updated_at=now() WHERE id=%s
    """, (status, error, run))
    conn.execute("UPDATE app.execution_jobs SET status='done',lease_until=NULL,updated_at=now() WHERE run_id=%s", (run,))
    if dispatched and not interrupted and not cancelled:
        conn.execute("""
            INSERT INTO app.model_connection_test_results
                (run_id,model_definition_id,request_config_generation,credential_version,accepted_order,status)
            SELECT run_id,model_definition_id,request_config_generation,credential_version,accepted_order,%s
            FROM app.model_test_requests WHERE run_id=%s ON CONFLICT DO NOTHING
        """, ("failed" if error else "passed", run))
    event(conn, run, f"run.{status}", {"status": status, "error_code": error})


def claim(conn, worker):
    job = conn.execute("""
        SELECT j.run_id,j.fencing_token,r.workspace_id,r.actor_user_id,r.created_at,r.started_at,r.status,
               t.model_definition_id,t.request_config_generation,t.credential_version
        FROM app.execution_jobs j JOIN app.runs r ON r.id=j.run_id
        JOIN app.model_test_requests t ON t.run_id=j.run_id
        WHERE r.kind='connection_test' AND (
            (j.status='ready' AND j.available_at<=now()) OR (j.status='leased' AND j.lease_until<=now()))
        ORDER BY j.available_at,j.id LIMIT 1 FOR UPDATE OF j SKIP LOCKED
    """).fetchone()
    if not job:
        return None
    run = job["run_id"]
    prior = conn.execute("""
        SELECT a.id,a.model_call_id,a.deadline_at FROM app.model_call_attempts a
        JOIN app.model_calls c ON c.id=a.model_call_id WHERE c.run_id=%s
    """, (run,)).fetchone()
    if prior:
        if prior["deadline_at"] > now():
            conn.execute("""
                UPDATE app.execution_jobs SET status='ready',lease_owner=NULL,lease_until=NULL,available_at=%s
                WHERE run_id=%s
            """, (prior["deadline_at"], run))
            return None
        metering.settle(conn, prior["id"], None)
        conn.execute("""
            UPDATE app.model_call_attempts SET state='interrupted',error_code='RESULT_UNKNOWN',finished_at=now()
            WHERE id=%s
        """, (prior["id"],))
        conn.execute("UPDATE app.model_calls SET status='interrupted' WHERE id=%s", (prior["model_call_id"],))
        finish(conn, run, "RESULT_UNKNOWN", interrupted=True)
        return None
    if job["status"] == "cancel_requested":
        finish(conn, run, None, cancelled=True)
        return None
    if not job["started_at"] and job["created_at"] + timedelta(minutes=5) <= now():
        finish(conn, run, "QUEUE_TIMEOUT")
        return None
    job["fencing_token"] += 1
    conn.execute("""
        UPDATE app.execution_jobs SET status='leased',lease_owner=%s,lease_until=now()+interval '30 seconds',
            fencing_token=%s,updated_at=now() WHERE run_id=%s
    """, (worker, job["fencing_token"], run))
    started = conn.execute("""
        UPDATE app.runs SET status='running',started_at=coalesce(started_at,now()),
            fencing_token=%s,updated_at=now() WHERE id=%s RETURNING started_at
    """, (job["fencing_token"], run)).fetchone()
    job["started_at"] = started["started_at"]
    event(conn, run, "run.running", {"status": "running"})
    return job


def locked_job(conn, job, worker):
    return conn.execute("""
        SELECT run_id FROM app.execution_jobs WHERE run_id=%s AND status='leased' AND lease_owner=%s
            AND fencing_token=%s AND lease_until>clock_timestamp() FOR UPDATE
    """, (job["run_id"], worker, job["fencing_token"])).fetchone()


def current_model(conn, job):
    actor = conn.execute("SELECT status FROM app.users WHERE id=%s FOR UPDATE", (job["actor_user_id"],)).fetchone()
    model = conn.execute("""
        SELECT m.*,c.status AS connection_status,c.base_url,c.credential_version,
               k.ciphertext,k.nonce,k.key_version
        FROM app.model_definitions m JOIN app.model_connections c ON c.id=m.connection_id
        JOIN app.credential_secrets k ON k.id=c.credential_id
        WHERE m.id=%s FOR UPDATE OF c,m
    """, (job["model_definition_id"],)).fetchone()
    if actor["status"] != "active" or not model or model["status"] != "active" or model["connection_status"] != "active":
        return None
    if any(model[field] != job[field] for field in ("request_config_generation", "credential_version")):
        return None
    return model


def aad(connection_id, endpoint):
    return f"provider-key:{connection_id}:{endpoint}"


def reserve_call(conn, job, model, purpose, deadline, estimate):
    allowed, reason = metering.admission(conn, job["workspace_id"])
    if not allowed:
        return None, reason
    call, attempt = uuid4(), uuid4()
    with conn.transaction() as transaction:
        conn.execute("""
            INSERT INTO app.model_calls(id,workspace_id,run_id,model_definition_id,logical_call_key,purpose,status)
            VALUES (%s,%s,%s,%s,%s,%s,'dispatching')
        """, (call, job["workspace_id"], job["run_id"], model["id"], purpose, purpose))
        conn.execute("""
            INSERT INTO app.model_call_attempts
                (id,model_call_id,workspace_id,attempt_number,state,credential_version,deadline_at,dispatched_at)
            VALUES (%s,%s,%s,1,'dispatching',%s,%s,now())
        """, (attempt, call, job["workspace_id"], model["credential_version"], deadline))
        error = metering.reserve(conn, job["workspace_id"], attempt, estimate, deadline, model["strict_budget_eligible"])
        if error:
            raise Rollback(transaction)
    return (call, attempt), error


def begin_dispatch(conn, job, worker, endpoint):
    conn.execute("SELECT id FROM app.users WHERE id=%s FOR SHARE",(job["actor_user_id"],))
    if not locked_job(conn, job, worker):
        return None
    run = job["run_id"]
    if conn.execute("SELECT status FROM app.runs WHERE id=%s",(run,)).fetchone()["status"] == "cancel_requested":
        finish(conn,run,None,cancelled=True)
        return None
    model = current_model(conn, job)
    if not model or model["base_url"] != endpoint:
        finish(conn, run, "MODEL_CONFIGURATION_CHANGED")
        return None

    deadline = min(now() + timedelta(seconds=45), job["started_at"] + timedelta(seconds=90))
    if deadline <= now():
        finish(conn, run, "RUN_TIMEOUT")
        return None
    output = min(32, model["max_output_tokens"])
    estimate = len(TEST_PROMPT[0]["content"].encode()) + 16 + output
    if estimate > model["context_limit_tokens"]:
        finish(conn, run, "CONTEXT_LIMIT")
        return None

    key = decrypt(model["nonce"] + model["ciphertext"], model["key_version"], aad(model["connection_id"], endpoint))
    ids, error = reserve_call(conn, job, model, "connection_test", deadline, estimate)
    if error:
        finish(conn, run, error)
        return None
    conn.execute("""
        UPDATE app.execution_jobs SET lease_until=clock_timestamp()+interval '30 seconds'
        WHERE run_id=%s
    """, (run,))
    return *ids, deadline, model["upstream_model"], output, key


def heartbeat(job, worker):
    with connection() as conn:
        if not locked_job(conn, job, worker):
            return False
        conn.execute("""
            UPDATE app.execution_jobs SET lease_until=clock_timestamp()+interval '30 seconds',updated_at=now()
            WHERE run_id=%s
        """, (job["run_id"],))
        return True


async def call_with_heartbeat(job, worker, target, key, model, output, deadline):
    request = asyncio.create_task(provider.request_text(
        target, key, model, TEST_PROMPT, output, timeout=max(0, (deadline-now()).total_seconds()),
        probe=True,
    ))
    next_heartbeat = asyncio.get_running_loop().time() + 10
    try:
        while not request.done():
            ready, _ = await asyncio.wait((request,), timeout=.25)
            if ready:
                break
            with connection() as conn:
                if not locked_job(conn, job, worker):
                    return None
                if conn.execute("SELECT status FROM app.runs WHERE id=%s",(job["run_id"],)).fetchone()["status"] == "cancel_requested":
                    request.cancel()
                    break
            if asyncio.get_running_loop().time() >= next_heartbeat:
                if not await asyncio.to_thread(heartbeat, job, worker):
                    return None
                next_heartbeat = asyncio.get_running_loop().time() + 10
        return await request
    finally:
        if not request.done():
            request.cancel()
            await asyncio.gather(request, return_exceptions=True)


def run_once(worker):
    with connection() as conn:
        job = claim(conn, worker)
        if not job:
            return False
        endpoint = conn.execute("""SELECT c.base_url FROM app.model_connections c JOIN app.model_definitions m
            ON m.connection_id=c.id WHERE m.id=%s""",(job["model_definition_id"],)).fetchone()["base_url"]
    try:
        target = asyncio.run(provider.preflight(endpoint))
        with connection() as conn:
            dispatch = begin_dispatch(conn, job, worker, endpoint)
    except (provider.ProviderFailure, RedisError, OSError, RuntimeError) as exc:
        with connection() as conn:
            if locked_job(conn, job, worker):
                finish(conn, job["run_id"], getattr(exc, "code", "DEPENDENCY_UNAVAILABLE"))
        return True
    if not dispatch:
        return True
    call, attempt, deadline, model, output, key = dispatch
    result = asyncio.run(call_with_heartbeat(job, worker, target, key, model, output, deadline))
    if result is None:
        return True
    _, usage, error = result
    with connection() as conn:
        if locked_job(conn, job, worker):
            metering.settle(conn, attempt, usage)
            state = "failed" if error else "completed"
            conn.execute("""
                UPDATE app.model_call_attempts SET state=%s,error_code=%s,finished_at=now(),updated_at=now() WHERE id=%s
            """, (state, error, attempt))
            conn.execute("UPDATE app.model_calls SET status=%s,updated_at=now() WHERE id=%s", (state, call))
            cancelled = conn.execute("SELECT status FROM app.runs WHERE id=%s",(job["run_id"],)).fetchone()["status"] == "cancel_requested"
            finish(conn, job["run_id"], error, dispatched=True, cancelled=cancelled)
    return True
