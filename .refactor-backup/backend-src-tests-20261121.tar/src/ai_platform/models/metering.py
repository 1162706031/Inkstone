from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from psycopg.types.json import Jsonb
from redis import Redis

from ai_platform.settings import settings

CHINA = ZoneInfo("Asia/Shanghai")


def month_bounds(month=None):
    local = datetime.now(CHINA) if month is None else datetime.strptime(month, "%Y-%m").replace(tzinfo=CHINA)
    start = local.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end = start.replace(year=start.year + (start.month == 12), month=start.month % 12 + 1)
    return start.astimezone(UTC), end.astimezone(UTC)


def policy(conn, workspace, *, lock=False):
    if lock:
        conn.execute("INSERT INTO app.quota_policies(workspace_id) VALUES (%s) ON CONFLICT DO NOTHING", (workspace,))
    result = conn.execute(
        "SELECT workspace_id,mode,monthly_token_limit,revision FROM app.quota_policies WHERE workspace_id=%s"
        + (" FOR UPDATE" if lock else ""), (workspace,),
    ).fetchone()
    return result or {"workspace_id": workspace, "mode": "soft", "monthly_token_limit": 1000000, "revision": 1}


def reserve(conn, workspace, attempt, estimate, deadline, strict_eligible):
    config = policy(conn, workspace, lock=True)
    if config["mode"] == "strict" and not strict_eligible:
        return "STRICT_BUDGET_UNSUPPORTED"
    start, end = month_bounds()
    conn.execute("""
        INSERT INTO app.quota_buckets(workspace_id,period_start,period_end,limit_tokens)
        VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING
    """, (workspace, start, end, config["monthly_token_limit"]))
    bucket = conn.execute("""
        UPDATE app.quota_buckets SET reserved_tokens=reserved_tokens+%s,updated_at=now()
        WHERE workspace_id=%s AND period_start=%s AND settled_tokens+reserved_tokens+%s<=limit_tokens
        RETURNING id
    """, (estimate, workspace, start, estimate)).fetchone()
    if not bucket:
        return "MONTHLY_QUOTA_EXCEEDED"
    conn.execute("""
        INSERT INTO app.quota_reservations(attempt_id,workspace_id,bucket_id,reserved_tokens,state,expires_at)
        VALUES (%s,%s,%s,%s,'reserved',%s)
    """, (attempt, workspace, bucket["id"], estimate, deadline))
    ledger(conn, workspace, bucket["id"], attempt, "reserve", estimate, "dispatch")
    return None


def ledger(conn, workspace, bucket, attempt, operation, amount, reason):
    conn.execute("""
        INSERT INTO app.quota_ledger(workspace_id,bucket_id,attempt_id,operation,amount,settlement_key,reason)
        VALUES (%s,%s,%s,%s,%s,%s,%s)
    """, (workspace, bucket, attempt, operation, amount, f"{attempt}:{operation}", reason))


def settle(conn, attempt, usage):
    row = conn.execute("""
        SELECT * FROM app.quota_reservations WHERE attempt_id=%s FOR UPDATE
    """, (attempt,)).fetchone()
    if not row or row["state"] != "reserved":
        return False
    workspace, bucket = row["workspace_id"], row["bucket_id"]
    source = "unknown" if usage is None else "reported"
    first, second = usage or (None, None)
    normalized = Jsonb({"input_tokens": first, "output_tokens": second}) if usage else None
    conn.execute("""
        INSERT INTO app.usage_records(attempt_id,workspace_id,input_tokens,output_tokens,normalized_usage,source)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (attempt, workspace, first, second, normalized, source))
    amount = 0 if usage is None else first + second
    if usage is not None:
        conn.execute("""
            UPDATE app.quota_buckets SET settled_tokens=settled_tokens+%s,
                reserved_tokens=reserved_tokens-%s,updated_at=now() WHERE id=%s
        """, (amount, row["reserved_tokens"], bucket))
    conn.execute("""
        UPDATE app.quota_reservations SET state=%s,settled_at=now() WHERE attempt_id=%s
    """, ("uncertain" if usage is None else "settled", attempt))
    ledger(conn, workspace, bucket, attempt, "settle", amount, source)
    return True


def reconcile(conn, attempt, usage, reason):
    row = conn.execute("""
        SELECT * FROM app.quota_reservations WHERE attempt_id=%s FOR UPDATE
    """, (attempt,)).fetchone()
    if not row or row["state"] != "uncertain":
        return False
    workspace, bucket = row["workspace_id"], row["bucket_id"]
    first, second = usage
    amount = first + second
    conn.execute("""
        UPDATE app.quota_buckets SET settled_tokens=settled_tokens+%s,
            reserved_tokens=reserved_tokens-%s,updated_at=now() WHERE id=%s
    """, (amount, row["reserved_tokens"], bucket))
    conn.execute("""
        UPDATE app.usage_records SET input_tokens=%s,output_tokens=%s,source='reported',normalized_usage=%s
        WHERE attempt_id=%s
    """, (first, second, Jsonb({"input_tokens": first, "output_tokens": second}), attempt))
    conn.execute("UPDATE app.quota_reservations SET state='settled',settled_at=now() WHERE attempt_id=%s", (attempt,))
    ledger(conn, workspace, bucket, attempt, "adjustment", amount, reason)
    return True


ADMISSION = """
redis.call('SET', KEYS[1], ARGV[1], 'EX', 180)
redis.call('SET', KEYS[2], ARGV[2], 'EX', 180)
redis.call('SET', KEYS[3], ARGV[3], 'EX', 180)
return tonumber(ARGV[1]) < 20 and tonumber(ARGV[2]) < 2 and tonumber(ARGV[3]) < 4 and 1 or 0
"""


def admission(conn, workspace):
    # All dispatchers use this short transaction lock. The authoritative attempt rows
    # restore Redis's rate and concurrency view before each decision.
    conn.execute("SELECT pg_advisory_xact_lock(1848103263)")
    counts = conn.execute("""
        SELECT count(*) FILTER (WHERE workspace_id=%s AND dispatched_at>now()-interval '60 seconds') AS recent,
               count(*) FILTER (WHERE workspace_id=%s AND state='dispatching' AND deadline_at>now()) AS local,
               count(*) FILTER (WHERE state='dispatching' AND deadline_at>now()) AS global
        FROM app.model_call_attempts
        WHERE dispatched_at>now()-interval '60 seconds' OR (state='dispatching' AND deadline_at>now())
    """, (workspace, workspace)).fetchone()
    return redis_admission(workspace, counts)


def redis_admission(workspace, counts):
    config = settings()
    url = config.redis_url
    if not url:
        return False, "REDIS_UNAVAILABLE"
    with Redis.from_url(url, socket_connect_timeout=3, socket_timeout=3) as redis:
        prefix = config.redis_prefix
        result = redis.eval(ADMISSION, 3, f"{prefix}:model:rate:{workspace}", f"{prefix}:model:active:{workspace}",
                            f"{prefix}:model:active:global", counts["recent"], counts["local"], counts["global"])
    return bool(result), "MODEL_ADMISSION_LIMIT"
