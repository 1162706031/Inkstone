import asyncio
from datetime import datetime, timedelta
from typing import Annotated
from uuid import UUID, uuid4

import psycopg
from fastapi import APIRouter, Header, HTTPException, Query, Request

from ai_platform.identity.router import authenticated
from ai_platform.models import execution, metering, provider
from ai_platform.models import schemas as s
from ai_platform.security import decrypt, digest, encrypt

router = APIRouter(prefix="/api/v1")
Limit = Annotated[int, Query(ge=1, le=100)]
Cursor = Annotated[str | None, Query(max_length=96)]

CONNECTIONS = "SELECT c.* FROM app.model_connections c"
MODELS = """
    SELECT m.*,coalesce(t.status,'untested') AS last_test_status,
           CASE WHEN t.status='passed' THEN 'verified' ELSE 'unverified' END AS capability_status,
           lr.id AS test_run_id,lr.status AS test_run_status,lr.created_at AS test_requested_at,
           CASE WHEN lr.status IN ('failed','interrupted') THEN lr.error_code END AS test_error
    FROM app.model_definitions m JOIN app.model_connections c ON c.id=m.connection_id
    LEFT JOIN LATERAL (
        SELECT status FROM app.model_connection_test_results
        WHERE model_definition_id=m.id AND request_config_generation=m.request_config_generation
          AND credential_version=c.credential_version ORDER BY accepted_order DESC LIMIT 1
    ) t ON true
    LEFT JOIN LATERAL (
        SELECT r.id,r.status,r.error_code,r.created_at FROM app.model_test_requests q JOIN app.runs r ON r.id=q.run_id
        WHERE q.model_definition_id=m.id ORDER BY q.accepted_order DESC LIMIT 1
    ) lr ON true
"""
RUNS = """
    SELECT id,conversation_id,kind,agent_version_id,status,error_code AS error,context_compression,
           input_message_id,output_message_id,created_at,started_at,finished_at,last_event_seq AS last_event_sequence
    FROM app.runs
"""


def get_row(conn, statement, params, message="Resource unavailable"):
    row = conn.execute(statement, params).fetchone()
    if row is None:
        raise HTTPException(404, message)
    return row


def workspace(conn, user_id):
    return get_row(conn, "SELECT id FROM app.workspaces WHERE owner_user_id=%s AND status='active'", (user_id,))["id"]


def audit(conn, request, actor, action, target, target_type):
    conn.execute("""
        INSERT INTO app.audit_events(actor_user_id,workspace_id,action,target_type,target_id,result,request_id)
        VALUES (%s,%s,%s,%s,%s,'success',%s)
    """, (actor["id"], workspace(conn, actor["id"]), action, target_type, target, request.state.request_id))


def page(conn, statement, order, params, cursor, limit, schema, time_column="created_at"):
    boundary = (None, None)
    if cursor:
        try:
            timestamp, row_id = cursor.split("|")
            boundary = (datetime.fromisoformat(timestamp), UUID(row_id))
            if boundary[0].tzinfo is None:
                raise ValueError
        except ValueError as exc:
            raise HTTPException(422, "Invalid cursor") from exc
    rows = conn.execute(statement + f"""
        AND (%s::timestamptz IS NULL OR ({order}.{time_column},{order}.id)>(%s,%s))
        ORDER BY {order}.{time_column},{order}.id LIMIT %s
    """, (*params, boundary[0], *boundary, limit + 1)).fetchall()
    next_cursor = None
    if len(rows) > limit:
        rows.pop()
        next_cursor = f"{rows[-1][time_column].isoformat()}|{rows[-1]['id']}"
    return s.Page(items=[schema.model_validate(row) for row in rows], next_cursor=next_cursor)


def secret_fields(key, connection_id, endpoint):
    sealed, version = encrypt(key, execution.aad(connection_id, endpoint))
    return sealed[12:], sealed[:12], version


@router.get("/admin/model-connections", operation_id="listConnections")
def list_connections(request: Request, limit: Limit = 20, cursor: Cursor = None) -> s.Page[s.ConnectionView]:
    with authenticated(request, admin=True) as (conn, _, _):
        return page(conn, CONNECTIONS + " WHERE true", "c", (), cursor, limit, s.ConnectionView)


@router.post("/admin/model-connections", operation_id="createConnection", status_code=201)
def create_connection(data: s.ConnectionCreate, request: Request) -> s.ConnectionView:
    with authenticated(request, admin=True) as (conn, _, user):
        try:
            endpoint = provider.normalize_endpoint(data.base_url)
        except provider.ProviderFailure as exc:
            raise HTTPException(422, "Invalid provider endpoint") from exc
        connection_id, secret_id = uuid4(), uuid4()
        conn.execute("""
            INSERT INTO app.credential_secrets(id,ciphertext,nonce,key_version) VALUES (%s,%s,%s,%s)
        """, (secret_id, *secret_fields(data.api_key, connection_id, endpoint)))
        row = conn.execute("""
            INSERT INTO app.model_connections(id,name,base_url,protocol,credential_id)
            VALUES (%s,%s,%s,%s,%s) RETURNING *
        """, (connection_id, data.name, endpoint, data.protocol, secret_id)).fetchone()
        audit(conn, request, user, "connection.created", connection_id, "model_connection")
        return s.ConnectionView.model_validate(row)


@router.get("/admin/model-connections/{connection_id}", operation_id="getConnection")
def get_connection(connection_id: UUID, request: Request) -> s.ConnectionView:
    with authenticated(request, admin=True) as (conn, _, _):
        return s.ConnectionView.model_validate(get_row(conn, CONNECTIONS + " WHERE c.id=%s", (connection_id,)))


@router.patch("/admin/model-connections/{connection_id}", operation_id="updateConnection")
def update_connection(connection_id: UUID, data: s.ConnectionPatch, request: Request) -> s.ConnectionView:
    with authenticated(request, admin=True) as (conn, _, user):
        existing = get_row(conn, CONNECTIONS + " WHERE c.id=%s FOR UPDATE", (connection_id,))
        if existing["revision"] != data.revision:
            raise HTTPException(409, "Connection revision conflict")
        version = existing["credential_version"]
        if data.api_key is not None:
            version += 1
            conn.execute("""
                UPDATE app.credential_secrets SET ciphertext=%s,nonce=%s,key_version=%s,version=%s,updated_at=now()
                WHERE id=%s
            """, (*secret_fields(data.api_key, connection_id, existing["base_url"]), version, existing["credential_id"]))
            conn.execute("""
                UPDATE app.model_definitions SET strict_budget_eligible=false
                WHERE connection_id=%s AND strict_budget_eligible
            """, (connection_id,))
        row = conn.execute("""
            UPDATE app.model_connections SET name=coalesce(%s,name),status=coalesce(%s,status),
                credential_version=%s,revision=revision+1,updated_at=now() WHERE id=%s RETURNING *
        """, (data.name, data.status, version, connection_id)).fetchone()
        audit(conn, request, user, "connection.updated", connection_id, "model_connection")
        return s.ConnectionView.model_validate(row)


@router.delete("/admin/model-connections/{connection_id}", operation_id="deleteConnection", status_code=204)
def delete_connection(connection_id: UUID, request: Request) -> None:
    with authenticated(request, admin=True) as (conn, _, user):
        row = get_row(conn, CONNECTIONS + " WHERE c.id=%s FOR UPDATE", (connection_id,))
        try:
            conn.execute("DELETE FROM app.model_definitions WHERE connection_id=%s", (connection_id,))
            conn.execute("DELETE FROM app.model_connections WHERE id=%s", (connection_id,))
        except psycopg.errors.ForeignKeyViolation as exc:
            raise HTTPException(409, "Connection is in use") from exc
        conn.execute("DELETE FROM app.credential_secrets WHERE id=%s", (row["credential_id"],))
        audit(conn, request, user, "connection.deleted", connection_id, "model_connection")


@router.get("/admin/model-connections/{connection_id}/models", operation_id="listConnectionModels")
def list_models(connection_id: UUID, request: Request, limit: Limit = 20, cursor: Cursor = None) -> s.Page[s.ModelView]:
    with authenticated(request, admin=True) as (conn, _, _):
        get_row(conn, CONNECTIONS + " WHERE c.id=%s", (connection_id,))
        return page(conn, MODELS + " WHERE m.connection_id=%s", "m", (connection_id,), cursor, limit, s.ModelView)


@router.post("/admin/model-connections/{connection_id}/models", operation_id="createModel", status_code=201)
def create_model(connection_id: UUID, data: s.ModelCreate, request: Request) -> s.ModelView:
    with authenticated(request, admin=True) as (conn, _, user):
        get_row(conn, CONNECTIONS + " WHERE c.id=%s FOR UPDATE", (connection_id,))
        try:
            row = conn.execute("""
                INSERT INTO app.model_definitions
                    (connection_id,upstream_model,display_name,context_limit_tokens,
                     max_output_tokens,supports_temperature,usage_support)
                VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING *
            """, (connection_id, data.upstream_model, data.display_name, data.context_limit_tokens,
                  data.max_output_tokens, data.supports_temperature, data.usage_support)).fetchone()
        except psycopg.errors.UniqueViolation as exc:
            raise HTTPException(409, "Model already exists") from exc
        audit(conn, request, user, "model.created", row["id"], "model_definition")
        return s.ModelView.model_validate({**row, "last_test_status": "untested"})


async def _discover(endpoint, key):
    return await provider.list_models(await provider.preflight(endpoint), key)


DISCOVERY_ERRORS = {
    "UPSTREAM_UNAUTHORIZED": "Provider rejected the API key",
    "ENDPOINT_FORBIDDEN": "Provider endpoint is not allowed",
    "ENDPOINT_UNAVAILABLE": "Provider endpoint is unreachable",
    "UPSTREAM_TIMEOUT": "Provider did not respond in time",
}


@router.get("/admin/model-connections/{connection_id}/discover", operation_id="discoverModels")
def discover_models(connection_id: UUID, request: Request) -> s.Discovery:
    """List models the provider reports via ``GET {base_url}/models``."""
    with authenticated(request, admin=True) as (conn, _, _):
        row = get_row(conn, """
            SELECT c.id,c.base_url,k.ciphertext,k.nonce,k.key_version FROM app.model_connections c
            JOIN app.credential_secrets k ON k.id=c.credential_id WHERE c.id=%s
        """, (connection_id,))
        known = {r["upstream_model"] for r in conn.execute(
            "SELECT upstream_model FROM app.model_definitions WHERE connection_id=%s", (connection_id,))}
    key = decrypt(row["nonce"] + row["ciphertext"], row["key_version"], execution.aad(row["id"], row["base_url"]))
    try:
        found = asyncio.run(_discover(row["base_url"], key))
    except provider.ProviderFailure as exc:
        raise HTTPException(502, DISCOVERY_ERRORS.get(exc.code, f"Provider model listing failed ({exc.code})")) from exc
    return s.Discovery(items=[
        s.DiscoveredModel(upstream_model=m["id"], context_limit_tokens=m["context_length"],
                          registered=m["id"] in known) for m in found
    ])


@router.post("/admin/model-connections/{connection_id}/models/import", operation_id="importModels")
def import_models(connection_id: UUID, data: s.ModelImport, request: Request) -> s.ImportResult:
    """Register several upstream models at once; existing identifiers are skipped."""
    with authenticated(request, admin=True) as (conn, _, user):
        get_row(conn, CONNECTIONS + " WHERE c.id=%s FOR UPDATE", (connection_id,))
        created = 0
        for item in {m.upstream_model: m for m in data.models}.values():
            context = item.context_limit_tokens or 8192
            output = min(4096, max(1, context // 4))
            row = conn.execute("""
                INSERT INTO app.model_definitions
                    (connection_id,upstream_model,display_name,context_limit_tokens,
                     max_output_tokens,supports_temperature,usage_support)
                VALUES (%s,%s,%s,%s,%s,true,'unknown')
                ON CONFLICT (connection_id,upstream_model) DO NOTHING RETURNING id
            """, (connection_id, item.upstream_model, item.display_name or item.upstream_model[:80],
                  context, output)).fetchone()
            if row:
                created += 1
                audit(conn, request, user, "model.created", row["id"], "model_definition")
        return s.ImportResult(created=created, skipped=len(data.models) - created)


@router.patch("/admin/models/{model_id}", operation_id="updateModel")
def update_model(model_id: UUID, data: s.ModelPatch, request: Request) -> s.ModelView:
    with authenticated(request, admin=True) as (conn, _, user):
        existing = get_row(conn, """
            SELECT m.* FROM app.model_definitions m JOIN app.model_connections c ON c.id=m.connection_id
            WHERE m.id=%s FOR UPDATE OF c,m
        """, (model_id,))
        if existing["revision"] != data.revision:
            raise HTTPException(409, "Model revision conflict")
        fields = data.model_dump(exclude_unset=True, exclude={"revision"})
        updated = {**existing, **fields}
        if updated["max_output_tokens"] >= updated["context_limit_tokens"]:
            raise HTTPException(422, "Output must leave room for input")
        request_fields = ("upstream_model", "context_limit_tokens", "max_output_tokens", "supports_temperature")
        changed = any(updated[key] != existing[key] for key in request_fields)
        try:
            conn.execute("""
                UPDATE app.model_definitions SET upstream_model=%s,context_limit_tokens=%s,max_output_tokens=%s,
                    supports_temperature=%s,display_name=%s,status=%s,revision=revision+1,
                    request_config_generation=request_config_generation+%s,
                    strict_budget_eligible=strict_budget_eligible AND NOT %s,updated_at=now() WHERE id=%s
            """, (*(updated[key] for key in request_fields), updated["display_name"], updated["status"],
                  int(changed), changed, model_id))
        except psycopg.errors.UniqueViolation as exc:
            raise HTTPException(409, "Model already exists") from exc
        audit(conn, request, user, "model.updated", model_id, "model_definition")
        return s.ModelView.model_validate(get_row(conn, MODELS + " WHERE m.id=%s", (model_id,)))


@router.get("/models", operation_id="listAvailableModels")
def available_models(request: Request, cursor: Cursor = None, limit: Limit = 20) -> s.Page[s.AvailableModelView]:
    with authenticated(request) as (conn, _, user):
        workspace(conn, user["id"])
        return page(conn, MODELS + " WHERE c.status='active' AND m.status='active' AND t.status='passed'",
                    "m", (), cursor, limit, s.AvailableModelView)


@router.post("/admin/model-connections/{connection_id}/test", operation_id="testConnection", status_code=202)
def test_connection(
    connection_id: UUID, data: s.ModelSelection, request: Request,
    idempotency_key: Annotated[str, Header(min_length=1, max_length=128)],
) -> s.RunView:
    with authenticated(request, admin=True) as (conn, _, user):
        owner = workspace(conn, user["id"])
        key_hash = digest(idempotency_key)
        request_hash = digest(str(data.model_definition_id))
        args = (owner, user["id"], connection_id, key_hash)
        prior = conn.execute("""
            SELECT request_hash,run_id,expires_at FROM app.idempotency_records
            WHERE workspace_id=%s AND actor_user_id=%s AND operation='connection_test' AND resource_id=%s
                  AND key_hash=%s FOR UPDATE
        """, args).fetchone()
        if prior and prior["expires_at"] > execution.now():
            if prior["request_hash"] != request_hash:
                raise HTTPException(409, "Idempotency key is already bound to a different model")
            return s.RunView.model_validate(get_row(conn, RUNS + " WHERE id=%s", (prior["run_id"],)))
        if prior:
            conn.execute("DELETE FROM app.idempotency_records WHERE run_id=%s", (prior["run_id"],))
        model = get_row(conn, """
            SELECT c.credential_version,c.status AS connection_status,m.status,m.request_config_generation
            FROM app.model_definitions m JOIN app.model_connections c ON c.id=m.connection_id
            WHERE c.id=%s AND m.id=%s FOR UPDATE OF c,m
        """, (connection_id, data.model_definition_id))
        if model["status"] != "active" or model["connection_status"] != "active":
            raise HTTPException(409, "Model is disabled")
        run = uuid4()
        conn.execute("""
            INSERT INTO app.runs(id,workspace_id,actor_user_id,kind,status)
            VALUES (%s,%s,%s,'connection_test','queued')
        """, (run, owner, user["id"]))
        conn.execute("INSERT INTO app.execution_jobs(run_id) VALUES (%s)", (run,))
        conn.execute("""
            INSERT INTO app.model_test_requests(run_id,model_definition_id,request_config_generation,credential_version)
            VALUES (%s,%s,%s,%s)
        """, (run, data.model_definition_id, model["request_config_generation"], model["credential_version"]))
        conn.execute("""
            INSERT INTO app.idempotency_records(workspace_id,actor_user_id,operation,resource_id,key_hash,
                                                request_hash,run_id,expires_at)
            VALUES (%s,%s,'connection_test',%s,%s,%s,%s,now()+interval '24 hours')
        """, (*args, request_hash, run))
        execution.event(conn, run, "run.queued", {"status": "queued"})
        audit(conn, request, user, "connection.test_started", connection_id, "model_connection")
        return s.RunView.model_validate(get_row(conn, RUNS + " WHERE id=%s", (run,)))



@router.get("/admin/users/{user_id}/quota", operation_id="getQuota")
def get_quota(user_id: UUID, request: Request) -> s.QuotaView:
    with authenticated(request, admin=True) as (conn, _, _):
        return s.QuotaView.model_validate(metering.policy(conn, workspace(conn, user_id)))


@router.patch("/admin/users/{user_id}/quota", operation_id="updateQuota")
def update_quota(user_id: UUID, data: s.QuotaPatch, request: Request) -> s.QuotaView:
    with authenticated(request, admin=True) as (conn, _, user):
        owner = workspace(conn, user_id)
        prior = metering.policy(conn, owner, lock=True)
        if prior["revision"] != data.revision:
            raise HTTPException(409, "Quota revision conflict")
        row = conn.execute("""
            UPDATE app.quota_policies SET monthly_token_limit=%s,mode=%s,revision=revision+1,updated_at=now()
            WHERE workspace_id=%s RETURNING *
        """, (data.monthly_token_limit, data.mode, owner)).fetchone()
        start, _ = metering.month_bounds()
        conn.execute("""
            UPDATE app.quota_buckets SET limit_tokens=%s,updated_at=now() WHERE workspace_id=%s AND period_start=%s
        """, (data.monthly_token_limit, owner, start))
        audit(conn, request, user, "quota.updated", user_id, "user")
        return s.QuotaView.model_validate(row)


@router.get("/usage/summary", operation_id="getUsageSummary")
def summary(request: Request, month: Annotated[str | None, Query(pattern=r"^\d{4}-\d{2}$")] = None) -> s.UsageSummary:
    try:
        start, end = metering.month_bounds(month)
    except ValueError as exc:
        raise HTTPException(422, "Invalid month") from exc
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        policy = metering.policy(conn, owner)
        row = conn.execute("""
            SELECT b.limit_tokens,b.settled_tokens,b.reserved_tokens,
                coalesce(sum(r.reserved_tokens) FILTER (WHERE r.state='uncertain'),0) AS uncertain,
                count(*) FILTER (WHERE u.source='unknown') AS unknown,
                count(*) FILTER (WHERE u.attempt_id IS NOT NULL AND u.estimated_cost IS NULL) AS unpriced
            FROM app.quota_buckets b LEFT JOIN app.quota_reservations r ON r.bucket_id=b.id
            LEFT JOIN app.usage_records u ON u.attempt_id=r.attempt_id
            WHERE b.workspace_id=%s AND b.period_start=%s GROUP BY b.id
        """, (owner, start)).fetchone()
        totals = row or {"limit_tokens": policy["monthly_token_limit"], "settled_tokens": 0,
                         "reserved_tokens": 0, "uncertain": 0, "unknown": 0, "unpriced": 0}
        return s.UsageSummary(
            period_start=start, period_end=end, mode=policy["mode"], token_limit=totals["limit_tokens"],
            confirmed_tokens=totals["settled_tokens"], reserved_tokens=totals["reserved_tokens"]-totals["uncertain"],
            uncertain_reserved_tokens=totals["uncertain"], unknown_attempts=totals["unknown"],
            remaining_tokens=max(0, totals["limit_tokens"]-totals["settled_tokens"]-totals["reserved_tokens"]),
            estimated_costs=[], unpriced_attempts=totals["unpriced"],
        )


@router.get("/usage/attempts", operation_id="listUsageAttempts")
def attempts(
    request: Request, cursor: Cursor = None, limit: Limit = 20,
    start: Annotated[datetime | None, Query(alias="from")] = None,
    end: Annotated[datetime | None, Query(alias="to")] = None,
    status: Annotated[str | None, Query(max_length=40)] = None,
    model_definition_id: UUID | None = None,
) -> s.Page[s.AttemptView]:
    end = end or execution.now()
    start = start or end-timedelta(days=90)
    if start.tzinfo is None or end.tzinfo is None or not timedelta(0) < end-start <= timedelta(days=90):
        raise HTTPException(422, "Invalid usage date range")
    with authenticated(request) as (conn, _, user):
        owner = workspace(conn, user["id"])
        statement = """
            SELECT a.id,a.model_call_id,c.run_id,c.model_definition_id,c.purpose,a.state,
                u.input_tokens,u.output_tokens,u.estimated_cost::text AS cost,u.currency,
                coalesce(u.source,'unknown') AS usage_source,a.dispatched_at AS started_at,
                a.finished_at,a.error_code,a.created_at
            FROM app.model_call_attempts a JOIN app.model_calls c ON c.id=a.model_call_id
            LEFT JOIN app.usage_records u ON u.attempt_id=a.id
            WHERE a.workspace_id=%s AND a.created_at>=%s AND a.created_at<%s
                AND (%s::text IS NULL OR a.state=%s) AND (%s::uuid IS NULL OR c.model_definition_id=%s)
        """
        return page(conn, statement, "a", (owner, start, end, status, status, model_definition_id, model_definition_id),
                    cursor, limit, s.AttemptView)
