from datetime import UTC, datetime, timedelta
from hmac import compare_digest
from uuid import UUID

import pyotp
from fastapi import HTTPException, Request, Response
from redis import Redis

from ai_platform.security import decrypt, digest, password_hasher, token
from ai_platform.settings import settings


def now():
    return datetime.now(UTC)


def audit(conn, action, target, *, actor=None, request_id="cli"):
    conn.execute("""
        INSERT INTO app.audit_events(actor_user_id, workspace_id, action, target_type,
                                     target_id, result, request_id)
        VALUES (%s, (SELECT id FROM app.workspaces WHERE owner_user_id = %s),
                %s, 'user', %s, 'success', %s)
    """, (actor, actor, action, target, request_id))


def bootstrap_admin(conn):
    conn.execute("SELECT pg_advisory_xact_lock(1848103262)")
    if conn.execute("SELECT id FROM app.users WHERE role = 'admin' OR username = 'admin'").fetchone():
        return False
    user = conn.execute("""
        INSERT INTO app.users(username,display_name,password_hash,must_change_password,role,status)
        VALUES ('admin','Administrator',%s,true,'admin','active') RETURNING id
    """, (password_hasher.hash("admin"),)).fetchone()
    conn.execute("INSERT INTO app.workspaces(owner_user_id) VALUES (%s)", (user["id"],))
    audit(conn, "admin.bootstrap", user["id"])
    return True


def reset_admin_mfa(conn, username):
    user = conn.execute("""
        UPDATE app.users SET mfa_secret_ciphertext=NULL, mfa_key_version=NULL, mfa_last_counter=NULL,
                             revision=revision+1, updated_at=now()
        WHERE username=%s AND role='admin' RETURNING id
    """, (username,)).fetchone()
    if user is None:
        return False
    revoke(conn, user["id"])
    conn.execute("DELETE FROM app.mfa_recovery_codes WHERE user_id=%s", (user["id"],))
    audit(conn, "admin.mfa_reset", user["id"])
    return True


def csrf_token(raw: str) -> str:
    return digest("ai-platform-csrf:" + raw).hex()


def session(conn, request: Request):
    raw = request.cookies.get(settings().session_cookie)
    if not raw or len(raw) != 43:
        return None
    hashed = digest(raw)
    owner = conn.execute("SELECT user_id FROM app.auth_sessions WHERE token_hash=%s", (hashed,)).fetchone()
    if not owner:
        return None
    user = None
    if owner["user_id"]:
        user = conn.execute("SELECT * FROM app.users WHERE id=%s FOR UPDATE", (owner["user_id"],)).fetchone()
        if not user or user["status"] != "active":
            return None
    current = conn.execute("""
        SELECT * FROM app.auth_sessions WHERE token_hash=%s AND revoked_at IS NULL
        AND expires_at>clock_timestamp() AND idle_expires_at>clock_timestamp() FOR UPDATE
    """, (hashed,)).fetchone()
    if current:
        current.update(user=user, csrf_token=csrf_token(raw))
    return current


def new_session(conn, response: Response, stage, user_id=None, purpose=None):
    raw = token()
    issued = now()
    expires = issued + {"anonymous": timedelta(minutes=30), "preauth": timedelta(minutes=5),
                        "full": timedelta(days=7)}[stage]
    idle = min(expires, issued + timedelta(hours=12))
    csrf = csrf_token(raw)
    conn.execute("""
        INSERT INTO app.auth_sessions(user_id,token_hash,csrf_hash,stage,purpose,expires_at,idle_expires_at)
        VALUES (%s,%s,%s,%s,%s,%s,%s)
    """, (user_id, digest(raw), digest(csrf), stage, purpose, expires, idle))
    config = settings()
    response.set_cookie(
        config.session_cookie, raw, max_age=int((expires-issued).total_seconds()),
        secure=config.secure_cookie, httponly=True, samesite="lax", path="/",
    )
    return csrf


def revoke_one(conn, current):
    conn.execute("UPDATE app.auth_sessions SET revoked_at=now() WHERE id=%s", (current["id"],))


def revoke(conn, user_id, keep: UUID | None = None):
    conn.execute("""
        UPDATE app.auth_sessions SET revoked_at=now()
        WHERE user_id=%s AND revoked_at IS NULL AND id IS DISTINCT FROM %s
    """, (user_id, keep))


def clear_cookie(response):
    config = settings()
    response.delete_cookie(config.session_cookie, secure=config.secure_cookie, httponly=True, samesite="lax")


def require_csrf(request, current):
    value = request.headers.get("x-csrf-token", "")
    if (
        request.headers.get("origin") != settings().app_origin or not current or len(value) != 64
        or not compare_digest(digest(value), current["csrf_hash"])
    ):
        raise HTTPException(403, "CSRF validation failed")


def require_session(current, stage="full", *, purpose=None, admin=False):
    if not current or current["stage"] == "anonymous":
        raise HTTPException(401, "Sign in required")
    if current["stage"] != stage or (purpose and current["purpose"] != purpose):
        raise HTTPException(403, "Authentication step required")
    user = current["user"]
    if admin and user["role"] != "admin":
        raise HTTPException(403, "Administrator required")
    return user


def refresh(conn, current):
    if current["stage"] == "full":
        conn.execute("""
            UPDATE app.auth_sessions SET last_seen_at=now(),
                idle_expires_at=least(expires_at, now()+interval '12 hours') WHERE id=%s
        """, (current["id"],))


def require_recent(current):
    if not current["verified_until"] or current["verified_until"] <= now():
        raise HTTPException(403, "Recent MFA required")


def issue_verification(conn, user_id, purpose):
    conn.execute("""
        UPDATE app.verification_tokens SET consumed_at=now()
        WHERE user_id=%s AND purpose=%s AND consumed_at IS NULL
    """, (user_id, purpose))
    raw = token()
    expires = now() + (timedelta(days=1) if purpose == "activation" else timedelta(minutes=30))
    conn.execute("""
        INSERT INTO app.verification_tokens(user_id,purpose,token_hash,expires_at)
        VALUES (%s,%s,%s,%s)
    """, (user_id, purpose, digest(raw), expires))
    return raw, expires


def consume_verification(conn, raw, purpose):
    hashed = digest(raw)
    record = conn.execute(
        "SELECT user_id FROM app.verification_tokens WHERE token_hash=%s AND purpose=%s", (hashed, purpose),
    ).fetchone()
    if record:
        user = conn.execute("SELECT * FROM app.users WHERE id=%s FOR UPDATE", (record["user_id"],)).fetchone()
        wanted = "pending" if purpose == "activation" else "active"
        if user["status"] == wanted and user["role"] == "member":
            result = conn.execute("""
                UPDATE app.verification_tokens SET consumed_at=now()
                WHERE token_hash=%s AND consumed_at IS NULL AND expires_at>clock_timestamp()
                RETURNING id
            """, (hashed,)).fetchone()
            if result:
                return user
    raise HTTPException(422, "Invalid or expired token")


def current_totp(user, code):
    secret = decrypt(user["mfa_secret_ciphertext"], user["mfa_key_version"], f"totp:{user['id']}")
    return totp_counter(secret, code, user["mfa_last_counter"])


def totp_counter(secret, code, last=None):
    totp = pyotp.TOTP(secret)
    step = totp.timecode(now())
    for counter in (step-1, step, step+1):
        if (last is None or counter > last) and compare_digest(totp.generate_otp(counter), code):
            return counter
    raise HTTPException(401, "Invalid authentication code")


RESERVE = """
for i=1,2 do
    if tonumber(redis.call('GET',KEYS[i]) or '0') >= tonumber(ARGV[i]) then return 0 end
end
for i=1,2 do
    local n=redis.call('INCR',KEYS[i])
    if n==1 then redis.call('PEXPIRE',KEYS[i],900000) end
end
return redis.call('PEXPIRETIME',KEYS[1]) .. ':' .. redis.call('PEXPIRETIME',KEYS[2])
"""

RELEASE = """
for i=1,2 do
    if redis.call('PEXPIRETIME',KEYS[i]) == tonumber(ARGV[i]) then
        redis.call('DECR',KEYS[i])
    end
end
"""


def rate_attempt(request, username):
    config = settings()
    dsn = config.redis_url
    if not dsn:
        raise HTTPException(503, "Authentication rate limiter unavailable")
    address = request.client.host if request.client else "unknown"
    keys = [f"{config.redis_prefix}:auth:" + digest(username).hex(),
            f"{config.redis_prefix}:auth-ip:" + digest(address).hex()]
    with Redis.from_url(dsn, socket_connect_timeout=3, socket_timeout=3) as redis:
        result = redis.eval(RESERVE, 2, *keys, 5, 30)
    if not result:
        raise HTTPException(429, "Try again later")
    expiries = result.split(b":")

    def release():
        with Redis.from_url(dsn, socket_connect_timeout=3, socket_timeout=3) as redis:
            redis.eval(RELEASE, 2, *keys, *expiries)

    return release


def purge_sessions(conn):
    conn.execute("""
        DELETE FROM app.auth_sessions WHERE id IN (
            SELECT id FROM app.auth_sessions WHERE expires_at<now()
                OR (revoked_at IS NOT NULL AND revoked_at<now()-interval '30 minutes')
            ORDER BY expires_at LIMIT 5000 FOR UPDATE SKIP LOCKED
        )
    """)
