from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Annotated
from uuid import UUID

import psycopg
import pyotp
from fastapi import APIRouter, HTTPException, Query, Request, Response

from ai_platform.db import connection
from ai_platform.identity import schemas as s
from ai_platform.identity import service as auth
from ai_platform.security import decrypt, digest, encrypt, password_hasher, password_matches, token

router = APIRouter(prefix="/api/v1")


@contextmanager
def authenticated(request, *, admin=False, stage="full", purpose=None):
    with connection() as conn:
        current = auth.session(conn, request)
        user = auth.require_session(current, stage, purpose=purpose, admin=admin)
        if request.method not in ("GET", "HEAD"):
            auth.require_csrf(request, current)
        auth.refresh(conn, current)
        yield conn, current, user


def record(conn, request, user, action, target):
    auth.audit(conn, action, target, actor=user["id"], request_id=request.state.request_id)


def set_password(conn, user, password):
    conn.execute("""
        UPDATE app.users SET password_hash=%s,must_change_password=false,
            status='active',revision=revision+1,updated_at=now() WHERE id=%s
    """, (password_hasher.hash(password), user["id"]))
    auth.revoke(conn, user["id"])


def check_password(user, password):
    if not password_matches(user["password_hash"] if user else None, password):
        raise HTTPException(401, "Invalid credentials")


@router.get("/auth/csrf", operation_id="getCsrf")
def csrf(request: Request, response: Response) -> s.CSRFView:
    with connection() as conn:
        current = auth.session(conn, request)
        raw = current["csrf_token"] if current else auth.new_session(conn, response, "anonymous")
        return s.CSRFView(csrf_token=raw)


@router.post("/auth/login", operation_id="login", response_model_exclude_none=True)
def login(payload: s.Login, request: Request, response: Response) -> s.LoginView:
    with connection() as conn:
        current = auth.session(conn, request)
        auth.require_csrf(request, current)
        if current["stage"] != "anonymous":
            raise HTTPException(409, "Sign out before starting a new session")
        release = auth.rate_attempt(request, payload.username)
        user = conn.execute(
            "SELECT * FROM app.users WHERE username=%s AND status<>'deleted' FOR UPDATE", (payload.username,),
        ).fetchone()
        check_password(user, payload.password)
        if user["status"] != "active":
            raise HTTPException(401, "Invalid credentials")
        release()
        auth.revoke_one(conn, current)
        if user["role"] == "member":
            auth.new_session(conn, response, "full", user["id"])
            return s.LoginView(next="ready", user=s.UserView.model_validate(user))
        step = "initial_password_change" if user["must_change_password"] else (
            "mfa_verify" if user["mfa_secret_ciphertext"] else "mfa_setup"
        )
        auth.new_session(conn, response, "preauth", user["id"], step)
        return s.LoginView(next=step)


@router.post("/auth/change-initial-password", status_code=204, operation_id="changeInitialPassword")
def change_initial(payload: s.NewPassword, request: Request, response: Response) -> None:
    with authenticated(request, admin=True, stage="preauth", purpose="initial_password_change") as (conn, _, user):
        set_password(conn, user, payload.new_password)
        record(conn, request, user, "admin.initial_password_changed", user["id"])
        auth.clear_cookie(response)


def use_token(request, response, raw, password, purpose):
    with connection() as conn:
        current = auth.session(conn, request)
        auth.require_csrf(request, current)
        if current["stage"] != "anonymous":
            raise HTTPException(409, "Sign out before using this token")
        user = auth.consume_verification(conn, raw, purpose)
        set_password(conn, user, password)
        auth.revoke_one(conn, current)
        auth.clear_cookie(response)
        record(conn, request, user, f"member.{purpose}", user["id"])


@router.post("/auth/activate", operation_id="activateMember")
def activate(payload: s.Activation, request: Request, response: Response) -> s.StatusResult:
    use_token(request, response, payload.token, payload.password, "activation")
    return s.StatusResult(status="activated")


@router.post("/auth/reset-password", operation_id="resetPassword")
def reset_password(payload: s.ResetPassword, request: Request, response: Response) -> s.StatusResult:
    use_token(request, response, payload.token, payload.new_password, "password_reset")
    return s.StatusResult(status="password_changed")


def check_mfa(conn, user, code):
    counter = auth.current_totp(user, code)
    conn.execute("UPDATE app.users SET mfa_last_counter=%s WHERE id=%s", (counter, user["id"]))


@router.post("/auth/reauthenticate", operation_id="reauthenticate")
def reauthenticate(payload: s.RecentAuth, request: Request) -> s.FreshView:
    with authenticated(request, admin=True) as (conn, current, user):
        release = auth.rate_attempt(request, user["username"])
        check_password(user, payload.password)
        check_mfa(conn, user, payload.code)
        release()
        until = auth.now() + timedelta(minutes=5)
        conn.execute("UPDATE app.auth_sessions SET verified_until=%s WHERE id=%s", (until, current["id"]))
        return s.FreshView(verified_until=until)


@contextmanager
def enrollment(request):
    with connection() as conn:
        current = auth.session(conn, request)
        changing = bool(current and current["stage"] == "full")
        if changing:
            user = auth.require_session(current, admin=True)
            auth.require_recent(current)
        else:
            user = auth.require_session(current, "preauth", purpose="mfa_setup", admin=True)
        auth.require_csrf(request, current)
        yield conn, current, user


@router.post("/auth/mfa/setup", operation_id="setupMfa")
def setup_mfa(request: Request) -> s.SetupView:
    with enrollment(request) as (conn, current, user):
        secret = pyotp.random_base32()
        encrypted, version = encrypt(secret, f"pending-totp:{current['id']}")
        conn.execute("""
            UPDATE app.auth_sessions SET pending_mfa_ciphertext=%s,pending_mfa_key_version=%s,
                pending_mfa_expires_at=least(expires_at,now()+interval '5 minutes') WHERE id=%s
        """, (encrypted, version, current["id"]))
        return s.SetupView(
            secret=secret, provisioning_uri=pyotp.TOTP(secret).provisioning_uri(user["username"], "AI Platform"),
        )


@router.post("/auth/mfa/confirm", operation_id="confirmMfa")
def confirm_mfa(payload: s.CodeInput, request: Request, response: Response) -> s.ConfirmView:
    with enrollment(request) as (conn, current, user):
        expires = current["pending_mfa_expires_at"]
        if not expires or expires <= auth.now():
            raise HTTPException(409, "Start MFA setup first")
        release = auth.rate_attempt(request, user["username"])
        secret = decrypt(current["pending_mfa_ciphertext"], current["pending_mfa_key_version"],
                         f"pending-totp:{current['id']}")
        counter = auth.totp_counter(secret, payload.code)
        release()
        encrypted, version = encrypt(secret, f"totp:{user['id']}")
        conn.execute("""
            UPDATE app.users SET mfa_secret_ciphertext=%s,mfa_key_version=%s,mfa_last_counter=%s,
                                 revision=revision+1,updated_at=now() WHERE id=%s
        """, (encrypted, version, counter, user["id"]))
        conn.execute("DELETE FROM app.mfa_recovery_codes WHERE user_id=%s", (user["id"],))
        codes = [token() for _ in range(10)]
        with conn.cursor() as cursor:
            cursor.executemany(
                "INSERT INTO app.mfa_recovery_codes(user_id,code_hash) VALUES (%s,%s)",
                [(user["id"], digest(code)) for code in codes],
            )
        auth.revoke(conn, user["id"])
        auth.new_session(conn, response, "full", user["id"])
        record(conn, request, user, "admin.mfa_enrolled", user["id"])
        return s.ConfirmView(user=s.UserView.model_validate(user), recovery_codes=codes)


@router.post("/auth/mfa/verify", operation_id="verifyMfa")
def verify_mfa(payload: s.Verify, request: Request, response: Response) -> s.UserResult:
    with authenticated(request, admin=True, stage="preauth", purpose="mfa_verify") as (conn, current, user):
        release = auth.rate_attempt(request, user["username"])
        if payload.code is not None:
            check_mfa(conn, user, payload.code)
        else:
            consumed = conn.execute("""
                UPDATE app.mfa_recovery_codes SET consumed_at=now()
                WHERE user_id=%s AND code_hash=%s AND consumed_at IS NULL RETURNING user_id
            """, (user["id"], digest(payload.recovery_code))).fetchone()
            if not consumed:
                raise HTTPException(401, "Invalid authentication code")
            record(conn, request, user, "admin.recovery_code_used", user["id"])
        release()
        auth.revoke_one(conn, current)
        auth.new_session(conn, response, "full", user["id"])
        return s.UserResult(user=s.UserView.model_validate(user))


@router.get("/auth/me", operation_id="getMe")
def me(request: Request) -> s.Me:
    with authenticated(request) as (conn, current, user):
        workspace = conn.execute("""
            SELECT id FROM app.workspaces WHERE owner_user_id=%s AND status='active'
        """, (user["id"],)).fetchone()
        if not workspace:
            raise HTTPException(403, "Workspace unavailable")
        return s.Me(user=s.UserView.model_validate(user), workspace_id=workspace["id"],
                    csrf_token=current["csrf_token"])


@router.post("/auth/logout", status_code=204, operation_id="logout")
def logout(request: Request, response: Response) -> None:
    with connection() as conn:
        current = auth.session(conn, request)
        auth.require_csrf(request, current)
        auth.revoke_one(conn, current)
        auth.clear_cookie(response)


@router.post("/auth/change-password", status_code=204, operation_id="changePassword")
def change_password(payload: s.ChangePassword, request: Request, response: Response) -> None:
    with authenticated(request) as (conn, current, user):
        if user["role"] == "admin":
            auth.require_recent(current)
        release = auth.rate_attempt(request, user["username"])
        check_password(user, payload.current_password)
        release()
        set_password(conn, user, payload.new_password)
        record(conn, request, user, "account.password_changed", user["id"])
        auth.clear_cookie(response)


@router.post("/auth/revoke-other-sessions", status_code=204, operation_id="revokeOtherSessions")
def revoke_other(payload: s.PasswordCheck, request: Request) -> None:
    with authenticated(request) as (conn, current, user):
        release = auth.rate_attempt(request, user["username"])
        check_password(user, payload.password)
        release()
        auth.revoke(conn, user["id"], current["id"])
        record(conn, request, user, "account.sessions_revoked", user["id"])


@router.get("/admin/users", operation_id="listUsers")
def list_users(request: Request, limit: Annotated[int, Query(ge=1, le=100)] = 20,
               status: s.Status | None = None, cursor: Annotated[str | None, Query(max_length=96)] = None) -> s.MemberPage:
    with authenticated(request, admin=True) as (conn, _, _):
        boundary = None
        if cursor:
            try:
                timestamp, user_id = cursor.split("|")
                boundary = (datetime.fromisoformat(timestamp), UUID(user_id))
                if boundary[0].tzinfo is None:
                    raise ValueError
            except ValueError as exc:
                raise HTTPException(422, "Invalid cursor") from exc
        rows = conn.execute("""
            SELECT * FROM app.users WHERE status<>'deleted' AND (%s::text IS NULL OR status=%s)
            AND (%s::timestamptz IS NULL OR (created_at,id)>(%s,%s))
            ORDER BY created_at,id LIMIT %s
        """, (status, status, boundary[0] if boundary else None,
              *(boundary or (None, None)), limit+1)).fetchall()
        next_cursor = None
        if len(rows) > limit:
            rows.pop()
            next_cursor = f"{rows[-1]['created_at'].isoformat()}|{rows[-1]['id']}"
        return s.MemberPage(items=[s.AdminUserView.model_validate(row) for row in rows], next_cursor=next_cursor)


@router.post("/admin/users", status_code=201, operation_id="createMember")
def create_member(payload: s.MemberCreate, request: Request) -> s.MemberCreated:
    with authenticated(request, admin=True) as (conn, _, actor):
        try:
            user = conn.execute("""
                INSERT INTO app.users(username,display_name,role,status)
                VALUES (%s,%s,'member','pending') RETURNING *
            """, (payload.username, payload.display_name)).fetchone()
        except psycopg.errors.UniqueViolation as exc:
            raise HTTPException(409, "Username already exists") from exc
        conn.execute("INSERT INTO app.workspaces(owner_user_id) VALUES (%s)", (user["id"],))
        raw, expires = auth.issue_verification(conn, user["id"], "activation")
        record(conn, request, actor, "member.created", user["id"])
        return s.MemberCreated(user=s.AdminUserView.model_validate(user), activation_token=raw, expires_at=expires)


def target_user(conn, user_id):
    user = conn.execute("SELECT * FROM app.users WHERE id=%s FOR UPDATE", (user_id,)).fetchone()
    if not user or user["status"] == "deleted":
        raise HTTPException(404, "Account unavailable")
    return user


def editable_member(conn, user_id, revision):
    user = target_user(conn, user_id)
    if user["role"] == "admin":
        raise HTTPException(403, "Administrator lifecycle requires operator access")
    if user["revision"] != revision:
        raise HTTPException(409, "成员信息已更新，请核对最新状态后重试。")
    return user


@router.post("/admin/users/{user_id}/activation-token", status_code=201, operation_id="reissueActivation")
def reissue(user_id: UUID, request: Request) -> s.ActivationToken:
    with authenticated(request, admin=True) as (conn, _, actor):
        user = target_user(conn, user_id)
        if user["role"] != "member" or user["status"] != "pending":
            raise HTTPException(409, "Account is not awaiting activation")
        raw, expires = auth.issue_verification(conn, user_id, "activation")
        record(conn, request, actor, "member.activation_reissued", user_id)
        return s.ActivationToken(activation_token=raw, expires_at=expires)


@router.post("/admin/users/{user_id}/password-reset", status_code=201, operation_id="issuePasswordReset")
def issue_reset(user_id: UUID, request: Request) -> s.ResetToken:
    with authenticated(request, admin=True) as (conn, _, actor):
        user = target_user(conn, user_id)
        if user["role"] != "member" or user["status"] != "active":
            raise HTTPException(409, "An active member is required")
        auth.revoke(conn, user_id)
        raw, expires = auth.issue_verification(conn, user_id, "password_reset")
        record(conn, request, actor, "member.password_reset_issued", user_id)
        return s.ResetToken(reset_token=raw, expires_at=expires)


@router.patch("/admin/users/{user_id}", operation_id="setMemberStatus")
def update_member(user_id: UUID, payload: s.MemberStatus, request: Request) -> s.AdminUserView:
    with authenticated(request, admin=True) as (conn, _, actor):
        user = editable_member(conn, user_id, payload.revision)
        status = payload.status
        if status == "active" and not user["password_hash"]:
            if user["status"] != "disabled":
                raise HTTPException(409, "请先使用激活令牌设置密码。")
            status = "pending"
        row = conn.execute("""
            UPDATE app.users SET status=%s,revision=revision+1,updated_at=now() WHERE id=%s RETURNING *
        """, (status, user_id)).fetchone()
        if status == "disabled":
            auth.revoke(conn, user_id)
        if status in ("disabled", "pending"):
            conn.execute("""
                UPDATE app.verification_tokens SET consumed_at=now()
                WHERE user_id=%s AND consumed_at IS NULL
            """, (user_id,))
        record(conn, request, actor, f"member.{status}", user_id)
        return s.AdminUserView.model_validate(row)


@router.delete("/admin/users/{user_id}", status_code=204, operation_id="deleteMember")
def delete_member(user_id: UUID, revision: Annotated[int, Query(ge=1)], request: Request) -> None:
    with authenticated(request, admin=True) as (conn, _, actor):
        editable_member(conn, user_id, revision)
        conn.execute("""
            UPDATE app.users SET status='deleted', password_hash=NULL, revision=revision+1, updated_at=now()
            WHERE id=%s
        """, (user_id,))
        conn.execute("UPDATE app.workspaces SET status='disabled' WHERE owner_user_id=%s", (user_id,))
        auth.revoke(conn, user_id)
        conn.execute("DELETE FROM app.verification_tokens WHERE user_id=%s", (user_id,))
        record(conn, request, actor, "member.deleted", user_id)
